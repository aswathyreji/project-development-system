<?php
include_once("phpfiles/connection.php");
$rid=$_POST['rid'];
$stat=$_POST['status'];
if($stat=='offline')
{
mysql_query("update login set online=0 where loginid='$rid'");
}
if($stat=='online')
{
mysql_query("update login set online=1 where loginid='$rid'");
}
?>