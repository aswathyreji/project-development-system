<?php
require_once('phpfiles/connection.php');
$user=$_SESSION['emp']['username'];

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<p>
  <?php
  $to_id=$user." - employee";
$sql="select * from inbox where to_id='$to_id'";
$result=mysql_query($sql)or die(mysql_error());
?>
</p>
<p>&nbsp; </p>
<form action="#" method="post" name="inbox" enctype="multipart/form-data">
  <table width="681" height="62" border="0" align="center">
  <tr>
    <td height="34" colspan="5" bgcolor="#330000"><font color="#FFFFFF"><img src="images/inbox.png" width="100" height="100"/><h2 align="center">INBOX</h2></font></td>
  </tr>
  <?php while($row=mysql_fetch_array($result))
{?>
	<tr bgcolor="#FFCC33">
    <td width="96"><font color="#000000"> From:</font><?php echo $row['from_id'];?></td>
    <td width="110"><font color="#000000"> Subect:</font><?php echo $row['subject'];?></td>
    <td width="331"><font color="#000000"> Message:</font><?php echo $row['message'];?></td>
    <td><a href="<?php echo $row['attachment']; ?>" target="_blank"><font color="#FF0000">click to download attachment</font></a></td></tr>
    
   <?php 
	
}
?>  
</table>
 <input name="delete" type="submit" value="CLEAR INBOX"/> 
<?php
if($_POST['delete'])
{
	
	$sql="delete from inbox where to_id='$to_id'";
	mysql_query($sql);
	echo "<script>alert('Inbox cleared')</script>";
	echo "<script>window.location='employee.php?view=inbox'</script>";
}
?>
</form>

</body>
</html>