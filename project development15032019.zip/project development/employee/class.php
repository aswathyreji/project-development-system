<?php
class demo
{
	function demo()
	{
		switch($_REQUEST['view'])
		{
			case sendmessage:
				include_once("employee/sendmessage.php");	
				break;
				
			case empworkstatus:
				include_once("employee/empworkstatus.php");	
				break;
				
			case inbox:
				include_once("employee/inbox.php");
				break;
			case sentbox:
				include_once("employee/sentbox.php");
				break;
				
			case changepassword:
				include_once("employee/changepassword.php");	
				break;
			case about:
				include_once("employee/about.php");	
				break;
			case completed_wrk:
				include_once("employee/completed_wrk.php");	
				break;
				
			
			
		}
	}
	
}