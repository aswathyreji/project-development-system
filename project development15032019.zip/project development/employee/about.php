<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<table width="95%" border="0">
  <tr>
    <td width="10%">&nbsp;</td>
    <td width="85%"><h2>About us</h2>
      <br />
                    <p>The objective of the system is providing a web application for a software company for supporting the planning of human resources and project management. Resource planning is a key to success of any project. The main concepts of the system are tasks on one hand and employees on the other hand. Tasks need to be completed in a certain time by a limited amount of employees with specific skills. The system supports the process of associating tasks to the right employees in a way that due dates are met while every employee gets a constant workload and also the work of each of the employee can be analyzed efficiently.  </p>
</tr>
</table>
</body>
</html>