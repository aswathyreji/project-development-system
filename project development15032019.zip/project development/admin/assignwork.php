<?php
require_once('phpfiles/connection.php');
$sql="select * from adminwork where status='0'";
$sql2="select * from login where user='manager' and status='1'";
$result=mysql_query($sql)or die(mysql_error());
$result1=mysql_query($sql2)or die(mysql_error());
?>
<script type="text/javascript" src="phpfiles/jquery-1.4.js"></script>
<script type="text/javascript">
prjt=function()
{

	var vals=$("#prtopic").val();
	$.post("admin/project.php",{prj:vals},function(data)
	{
		$(".ans").html(data);
		
	});
}
</script>
<script type="text/javascript">
 function datecheck(frmname)
{
  var frm = document.forms[frmname];
  if((frm.admindate.value <= frm.mgrwdate.value))
  {
    alert('Completion date should be less than clients date');
	frm.mgrwdate.focus();
	    return false;
  }
  else
  {
  
        return true; 
  

  }
}
</script>


<form action="#" method="post" name="mgrwork" enctype="multipart/form-data" onsubmit="return datecheck('mgrwork')" >
<table width="60%" border="0" align="center" cellpadding="1" cellspacing="5">
  <caption>
    <h2 align="left"><u><font color="#660000">ASSIGN PROJECT TO PROJECT MANAGER</font></u></h2>
  </caption>
 
  </tr>
  <tr>
    <th align="left">Project Manager</th>
    <th align="left">:</th>
    <td align="left"><select name="mgrcode"><?php
while($row1=mysql_fetch_array($result1))
{
	$username=$row1['username'];
	$sqlll="select * from manager where username='$username'";
$result2=mysql_query($sqlll)or die(mysql_error());
$row2=mysql_fetch_array($result2);	
?>

    <option value="<?php echo $row2['mgrcode'];?>"><?php echo $row2['mgrname'];?></option>
    <?php } ?>
    </select></td>
  </tr>
  <tr>
    <th align="left">Project Topic</th>
    <th align="left">:</th>
    <td align="left"><select name="mgrtopic" id="prtopic"  class="prtopic" onchange="prjt();" >
    <option>select</option> 
<?php
while($row=mysql_fetch_array($result))
{
?>

    <option value="<?php echo $row['workid'];?>"><?php echo $row['projecttopic'];?></option>
    <?php } ?>
    </select></td>
  </tr>
  </table>
  <div class="ans">
  </div>

<?php
if($_POST['submit'])
{
	$workid=$_POST['mgrcode'];
    $mgrcode=$_POST['mgrid'];
	$projecttopic=$_POST['mgrtopic'];
	$project=$_POST['mgrproject'];
	$extra=$_POST['mgrextra'];
	$completiondate=$_POST['mgrwdate'];
	

	
	
	$sql="insert into managerwork values('','$workid','$projecttopic','$project','$extra','$completiondate','','','unassigned','0')";
mysql_query($sql)or die(mysql_error());
$sql1="update adminwork set status='1',workstatus='On progress' where workid='$projecttopic'";
mysql_query($sql1) or die(mysql_error());
echo "<script>window.location='admin.php?view=assignproject'</script>";
}
?>
