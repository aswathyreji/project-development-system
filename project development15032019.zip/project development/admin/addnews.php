<?php
session_start();
require_once("phpfiles/connection.php");

$sql2n="select * from news";
$result2n=mysql_query($sql2n);
$row2n=mysql_fetch_array($result2n);

if($_POST['button3'])
{

$news=$_POST['news'];

$sqln="update news set news='$news'";
mysql_query($sqln);

echo "<script>alert('---News Updated---')</script>";
echo "<script>window.location='admin.php'</script>";
	
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
 <form id="form2" name="form2" method="post" action="">
                  <table width="100%" border="0">
                    <tr>
                      <td align="center"><textarea name="news" id="news" cols="45" rows="8"><?php echo $row2n['news']; ?></textarea>
                        <br />
                        <input type="submit" name="button3" id="button3" value="Submit" /></td>
                    </tr>
                  </table>
              </form>
</body>
</html>