<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Add project manager</title>
<script src="validation/gen_validatorv31.js" type="text/javascript"></script>
<script type="text/javascript">
 function DoCustomValidation(frmname)
{
  var frm = document.forms[frmname];
  if((frm.cpass.value != frm.cconpass.value))
  {
    alert('The Password and Confirm password cannot match!');
	frm.cpass.focus();
	    return false;
  }
  else
  {
  
        return true; 
  

  }
}
</script>
</head>
<body>
<?php
require_once('phpfiles/connection.php');
?>
<form action="" method="post" name="addmanager" enctype="multipart/form-data" onsubmit="return Validate()">
<table width="56%" border="0" align="center" cellpadding="1" cellspacing="5">
  <caption>
    <h2 align="left"><font color="#660000"><u>ADD PROJECT MANAGER</u></font></h2>
  </caption>
  <tr>
    <th align="left" width="27%">Manager Code</th>
    <th align="left" width="6%">:</th>
    <td width="67%" align="left"><input name="mcode" id="mcode" type="text" size="25" maxlength="3"/></td>
  </tr>
  <tr>
    <th align="left">Name</th>
    <th align="left">:</th>
    <td align="left"><input name="mname" type="text" size="25" maxlength="25" /></td>
  </tr>
  <tr>
    <th align="left">Domain</th>
    <th align="left">:</th>
    <td align="left"><input name="mdomain" type="text" size="25" maxlength="25" /></td>
  </tr>
  <tr>
    <th align="left">Upload Photo</th>
    <th align="left">:</th>
    <td align="left"><input name="mphoto" type="file" value="choose image"/></td>
  </tr>
  <tr>
    <th align="left">Upload Resume</th>
    <th align="left">:</th>
    <td align="left"><input name="mresume" type="file" /></td>
  </tr>
  <tr>
    <th align="left">Experience</th>  
    <th align="left">:</th> 
    <td align="left"><select name="mexp">
    <option value="" selected="selected">--SELECT--</option>
   <option value="0to1">0-1 years</option>
   <option value="1to2">1-2 years</option>
   <option value="2to3">2-3 years</option>
   <option value="3to4">3-4 years</option>
   <option value="more">more than 4 years</option>
   </select></td>
  </tr>
  <tr>
    <th align="left">Posted date</th>  
    <th align="left">:</th>
<td align="left"><div align="left"> <span class="style2">
        <input name="cage" type="text" id="event_Date"  class="textbox_slim" size="10" maxlength="13"  value="<?php echo $date;?>"  readonly="true" />
        </span>
        <input type="button" name="Button" value="..." class="pagefooter" onclick="displayCalendar(document.getElementById('event_Date'),'yyyy-mm-dd',this); "  title="click here to view calender" />
      </div>
</td>  </tr>
  <tr>
    <th align="left">Email</th>
    <th align="left">:</th>
    <th align="left"><input name="memail" type="text" size="25" /></th>
  </tr>
  <tr>
    <th align="left">Username</th> 
    <th align="left">:</th>  
    <td align="left"><input name="muname" type="text" size="25" /></td>
  </tr>
  <tr>
    <th align="left">Password</th>  
    <th align="left">:</th>
    <td align="left"><input name="mpass" type="password" size="25" /></td>
  </tr>
  <tr>
    <th align="left">Confirm Password</th>  
    <th align="left">:</th>
    <td align="left"><input name="mconpass" type="password" size="25" /></td>
  </tr>
   <tr>
    <th align="left">&nbsp;</th>
    <th align="left">&nbsp;</th>
    <th align="left">&nbsp;</th>
  </tr>
  <tr>
    <th align="left">&nbsp;</th>
    <th align="left">&nbsp;</th>
    <th align="left"><input name="submit" type="submit" value="SUBMIT" /><input name="mgr_reset" type="reset" value="RESET" /></th>
  </tr>
</table>
<?php
if($_POST['submit'])
{
	$mgrcode=$_POST['mcode'];
    $mgrname=$_POST['mname'];
	$mgrdomain=$_POST['mdomain'];
	$iname=$_FILES['mphoto']['name'];
	$itype=$_FILES['mphoto']['type'];
	$itmpname=$_FILES['mphoto']['tmp_name'];
	$irid=rand();
	$iname=$irid.$iname;
	$ipath="admin/uploads/".$iname;
	if(($itype=='image/jpeg')||($itype=='image/jpg'))
		{
		move_uploaded_file($itmpname,$ipath);
		}
	$rname=$_FILES['mresume']['name'];
	$rtype=$_FILES['mresume']['type'];
	$rtmpname=$_FILES['mresume']['tmp_name'];
	$rrid=rand();
	$rname=$rrid.$rname;
	$rpath="admin/uploads/".$rname;
	if(($rtype=='application/pdf')||($rtype=='application/vnd.openxmlformats-officedocument.wordprocessingml.document')||($rtype=='application/msword'))
		{
		move_uploaded_file($rtmpname,$rpath);
		}
	$mgrexp=$_POST['mexp'];
	$mgrdate=$_POST['mdate'];
	$mgremail=$_POST['memail'];
	$mgruname=$_POST['muname'];
	$mgrpass=md5($_POST['mpass']);
	
	
	$sql="insert into manager values('','$mgrcode','$mgrname','$mgrdomain','$mgruname','$ipath','$rpath','$mgrexp','$mgrdate','$mgremail')";
mysql_query($sql);

	$sql1="insert into login values('','manager','$mgruname','$mgrpass','1','0','$mgremail')";
mysql_query($sql1);
echo "<script>alert('Manager added')</script>";
		    
}
?>
</form>

<script  language="javascript" type="text/javascript">
	function Validate() 
{
//var code=document.addmanager.mcode .value;  
//  
//if (code==null || code=="")
//{  
//  alert("Pls enter the code");  
//  return false;  
//}
//if(document.addmanager.mname.value=="")
//{
//alert("Pls enter manager name ");
//return false;
//}
//else
//{
//if (!document.addmanager.mname.value.match(/^[a-zA-Z]+$/)) 
//   {
//        alert('Only alphabets are allowed');
//        return false;   
//   }
//}
//if (document.addmanager.mdomain.value == "")
//{
//alert(" Pls enter the domain");
//return false;
//}
var fileInput = document.getElementById('mphoto');
var filePath = fileInput.value;
var allowedExtensions = /(\.jpg|\.jpeg|\.png|\.gif)$/i;
if(document.addmanager.mphoto.value=="")
{
alert("Pls enter manager photo ");
return false;
}
	else 
	{
	if(!allowedExtensions.exec(filePath))
	{
        alert('Please upload file having extensions .jpeg/.jpg/.png/.gif only.');
        fileInput.value = '';
        return false;
    }
	}

}
// var frmvalidator = new Validator("addmanager");
// frmvalidator.addValidation("mcode","req","Please enter code for manager");
// frmvalidator.addValidation("mcode","maxlen=3","Maximum length alloted for manager code is 3");
// frmvalidator.addValidation("mcode","minlen=3","Minimum length alloted for manager code is 3");
// frmvalidator.addValidation("mcode","num");
// 
// var frmvalidator = new Validator("addmanager");
// frmvalidator.addValidation("mname","req","Please enter manager name");
//
// var frmvalidator = new Validator("addmanager");
// frmvalidator.addValidation("mdomain","req","Please enter domains");
// 
// var frmvalidator = new Validator("addmanager");
// frmvalidator.addValidation("mexp","req","Specify experience");
//  
// var frmvalidator = new Validator("addmanager");
// frmvalidator.addValidation("cage","req","Please enter posted date");
// 
// 
// var frmvalidator = new Validator("addmanager");
// frmvalidator.addValidation("memail","req","Please enter valid Email");
// frmvalidator.addValidation("memail","maxlen=60","Maximum length alloted for Email is 60");
// frmvalidator.addValidation("memail","email");
// 
// var frmvalidator = new Validator("addmanager");
// frmvalidator.addValidation("muname","req","Please enter Username");
//
// var frmvalidator = new Validator("addmanager"); 
// frmvalidator.addValidation("mpass","req","Please enter password");
// 
// var frmvalidator = new Validator("addmanager"); 
// frmvalidator.addValidation("mconpass","req","Please confirm password"); 
 
</script> 
</body>
</html>