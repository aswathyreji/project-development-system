<?php
class demo
{
	function demo()
	{
		switch($_REQUEST['view'])
		{
			case projectmanager:
				include_once("admin/projectmanager.php");	
				break;
			case assignproject:
				include_once("admin/assignwork.php");	
				break;
			case adminmgrworkstatus:
				include_once("admin/adminmgrworkstatus.php");	
				break;
			case adminworkstatus:
				include_once("admin/adminworkstatus.php");	
				break;
			case blockmanager:
				include_once("admin/blockmanager.php");	
				break;
			case sendmessage:
				include_once("admin/sendmessage.php");	
				break;
			case inbox:
				include_once("admin/inbox.php");	
				break;
			case sentbox:
				include_once("admin/sentbox.php");	
				break;
			case editmanager:
				include_once("admin/editmanager.php");	
				break;
			case client:
				include_once("admin/client.php");	
				break;
			case addnews:
				include_once("admin/addnews.php");	
				break;
			case changepassword:
				include_once("admin/changepassword.php");	
				break;
			case completed_wrk:
				include_once("admin/completed_wrk.php");	
				break;
		}
	}
	
}