<?php
session_start();
require_once('phpfiles/connection.php');
$user=$_SESSION['admin']['username'];

if($_POST['button'])
{
 $workstatus=$_POST['workstatus'];
 $sure=$_POST['checkbox1'];
 $rname=$_FILES['work']['name'];
	$rtype=$_FILES['work']['type'];
	$rtmpname=$_FILES['work']['tmp_name'];
	$rrid=rand();
	$rname=$rrid.$rname;
	$rpath="admin/uploads/".$rname;
	//if(($rtype=='application/pdf')||($rtype=='application/vnd.openxmlformats-officedocument.wordprocessingml.document')||($rtype=='application/msword'))
		{
		move_uploaded_file($rtmpname,$rpath);
		}
if($sure!="")
{

$t=date("Y-m-d");
  $sql6="update adminwork set work='$rpath',workstatus='$workstatus',workdonedate='$t',status='3' where workid='$sure'";
mysql_query($sql6) or die(mysql_error());

	echo "<script>alert('Work updated')</script>";
	echo "<script>window.location='admin.php?view=adminworkstatus'</script>";

}
else
{
	echo "<script>alert('please select checkBox')</script>";
	echo "<script>window.location='admin.php?view=adminworkstatus'</script>";
	
}

}




$sql3="select * from adminwork  where  workstatus='On progress' and status='1'";
$result3=mysql_query($sql3) or die(mysql_error());
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

 <table width="100%" border="0">
                    <tr>
                      <td width="20%" align="center" bgcolor="#c01e46"><strong><font color="#FFFFFF">Project Title</font></strong></td>
                      <td width="24%" align="center" bgcolor="#c01e46"><strong><font color="#FFFFFF">Extra</font></strong></td>
                     <td width="14%" align="center" bgcolor="#c01e46"><strong><font color="#FFFFFF">Completion Date</font></strong></td>
                      <td width="31%" align="center" bgcolor="#c01e46"><strong><font color="#FFFFFF">Work Status</font></strong></td>
                     
                    </tr>
                    <?php
					while($row3=mysql_fetch_array($result3))
					{
						
						
					?>
                    <tr>
                      <td align="center"><a href="<?php echo $row3['project']; ?>" target="_blank"><?php echo $row3['projecttopic']; ?></a></td>
                       <td align="center"><?php echo $row3['extra']; ?></td>
                      <td align="center"><?php echo $row3['completiondate']; ?></td>
                      <td align="center">
                      <?php
					 
                      $exp_date=$row3['completiondate'];
						$todays_date=date("d-m-Y");
							$today=strtotime($todays_date);
						$expiration_date=strtotime($exp_date);
						if(($expiration_date>$today))
						{
                      ?>
                      <form id="form1" name="form1" method="post" action="" enctype="multipart/form-data">
                        Sure
                            <input type="checkbox" name="checkbox1" id="checkbox" value="<?php echo $row3['workid']; ?>"/>
                        <select name="workstatus" id="workstatus">
                        <option></option>
						<option>Complete</option>

                          </select>
                        <input type="submit" name="button" id="button" value="ok" /><br />
                        <input type="file" name="work" />
                      </form>
                      <?php
						}
						else
						{
							$uid=$row3['workid'];
							$sql8="update adminwork  set status='2',workstatus='failed' where workid='$uid'";
							mysql_query($sql8);
							
						echo "Your work allowing date expired";	
						}
					  ?>
                      </td>
                     
                    </tr>
                    <?php
					}
					?>
                  </table>
</body>
</html>