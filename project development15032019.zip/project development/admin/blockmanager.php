<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<body>

<?php
require_once('phpfiles/connection.php');
$flag=$_REQUEST['flag'];
$mgrid=$_REQUEST['id'];
if($flag=='block')
{
	$sql2="select * from manager where mgrid='$mgrid'";
  $result2=mysql_query($sql2);
 $row2=mysql_fetch_array($result2);
 $uname1=$row2['username'];
 $sql3="update login set status='2' where username='$uname1'";
 mysql_query($sql3);
}
if($flag=='unblock')
{
	$sql2="select * from manager where mgrid='$mgrid'";
  $result2=mysql_query($sql2);
 $row2=mysql_fetch_array($result2);
 $uname1=$row2['username'];
 $sql3="update login set status='1' where username='$uname1'";
 mysql_query($sql3);
}
if($flag=='delete')
{
 $sql3="select username from manager where mgrid='$mgrid'";
  $result3=mysql_query($sql3);
 $row3=mysql_fetch_array($result3);
 $username=$row3['username'];
 $sql4="delete from manager where mgrid='$mgrid'";
  mysql_query($sql4);
 $sql5="delete from login where username='$username'";
  mysql_query($sql5);
}
?>
<table width="682" border="0" align="center" cellpadding="3" cellspacing="0">

<caption>
<h2><font color="#660000">PROJECT MANAGERS</font></h2>
</caption>
<tr bgcolor="#c01e46">
  <td align="center" width="10"><b><font color="#000000">Sl No</font></b></td>
  <td align="center" width="25" ><b><font color="#000000">Manager<br />Code</font></b></td>
  <td align="center" width="25"><b><font color="#000000">Manager<br />Name</font></b></td>
  <td align="center" width="25"><b><font color="#000000">Domain</font></b></td>
  <td align="center" width="40"><b><font color="#000000">Photo</font></b></td>
  <td align="center" width="30"><b><font color="#000000">Email</font></b></td>
   <td width="20">&nbsp;</td>
  <td width="20">&nbsp;</td>
  <td width="20" >&nbsp;</td>
 
</tr>
<?php
  $sql="select * from manager";
  $result=mysql_query($sql);
  
  $i=0;
  while($row=mysql_fetch_array($result))
  {
	  $uname=$row['username'];
	  $sql1="select * from login where username='$uname'";
  $result1=mysql_query($sql1);
  $row1=mysql_fetch_array($result1);
  $status=$row1['status'];
	  ?>
<tr>
  <td align="center"><?php echo $row['mgrid'];?></td>
  <td align="center"><?php echo $row['mgrcode'];?></td>
  <td align="center"><?php echo $row['mgrname'];?></td>
  <td align="center"><?php echo $row['mgrdomain'];?></td>
  <td align="center"><img src="<?php echo $row['mgrphoto'];?>" width="80" height="80" /></td>
  <td align="center"><?php echo $row['mgremail'];?></td>
  <td align="center">
  <?php if($status=='1')
		 {
			 ?>
    <a href="admin.php?view=blockmanager&flag=block&id=<?php echo $row['mgrid'];?>"><font color="#FF0000"><b><img src="images/unlock.png" width="40" height="40" border="0" title="Block"/></b></font></a>
    <?php
		 }
		 else if($status=='2')
		 {
			 ?>
    <a href="admin.php?view=blockmanager&flag=unblock&id=<?php echo $row['mgrid'];?>"><font color="#006600"><b><img src="images/block.png" title="Unblock" width="40" height="40" border="0"/></b></font></a>
    <?php } ?></td>
   <td width="95" align="center"><a href="admin.php?view=editmanager&mid=<?php echo $row['mgrid'];?>"><img src="images/edit.png" width="35" height="35" border="0" title="Edit"/></a></td>
   <td width="96" align="center"><a href="admin.php?view=blockmanager&flag=delete&id=<?php echo $row['mgrid'];?>"><img src="images/drop.png" width="35" height="35" border="0" title="Delete"/></a>
  <?php
		 
		 $i++;
		 ?>
</tr>
<?php
  }
  ?>
</table>
</body>
</html>