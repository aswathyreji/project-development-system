<html>
<head>
<title></title>
</head>
<body>
<?php
require_once('phpfiles/connection.php');
$mgrid=$_REQUEST['mid'];
?>
<form action="#" method="post" name="editmanager">
<table border="0" align="center" cellpadding="1" cellspacing="5">
  <caption>
    <h2 align="left"><font color="#660000"><u>EDIT MANAGER DETAILS</u></font></h2>
  </caption>
    <?php 
	$sql="select * from manager where mgrid='$mgrid'";
    $result=mysql_query($sql);
    $row=mysql_fetch_array($result);
	?>
	<tr>
    <th align="left">Edit Name</th>
    <th align="left">:</th>
    <td align="left"><input name="mname" type="text" size="25" maxlength="25" value="<?php echo $row['mgrname']; ?>"/></td>
  </tr>
  <tr>
    <th align="left">Edit Domain</th>
    <th align="left">:</th>
    <td align="left"><input name="mdomain" type="text" size="25" maxlength="25" value="<?php echo $row['mgrdomain']; ?>"/></td>
  </tr>	
  <tr>
    <th align="left">Edit Email</th>
    <th align="left">:</th>
    <td align="left"><input name="memail" type="text" size="25" maxlength="25" value="<?php echo $row['mgremail']; ?>"/></td>
  </tr>	
  <tr>
    <th align="left">&nbsp;</th>
    <th align="left">&nbsp;</th>
    <th align="left"><input name="update" type="submit" value="UPDATE" /></th>
  </tr>
 <?php
if($_POST['update'])
{
 
    $mgrname=$_POST['mname'];
	$mgrdomain=$_POST['mdomain'];
	$mgremail=$_POST['memail'];
	
	$sql2="update manager set mgrname='$mgrname',mgrdomain='$mgrdomain',mgremail='$mgremail' where mgrid='$mgrid'";
mysql_query($sql2);
echo "<script>window.location='admin.php?view=blockmanager'</script>";
}
?>
 
 
  </table>
    </form>
</body>
</html>