<html>
<head>
<title></title>
</head>
<body>
<?php
require_once('phpfiles/connection.php');
$flag=$_REQUEST['flag'];
$clid=$_REQUEST['id'];
if($flag=='delete')
{
 $sql="select username from client where clid='$clid'";
  $result=mysql_query($sql);
 $row=mysql_fetch_array($result);
 $username=$row['username'];
 $sql1="delete from client where clid='$clid'";
  mysql_query($sql1);
 $sql2="delete from login where username='$username'";
  mysql_query($sql2);
}
?>
<table align="center" cellpadding="3" cellspacing="0">
<caption>
<h2><font color="#660000">CLIENTS</font></h2>
</caption>
<tr bgcolor="#c01e46">
  <td width="20" align="center"><b><font color="#000000">Sl No</font></b></td>
  <td width="70" align="center"><b><font color="#000000">Name</font></b></td>
  <td width="75" align="center"><b><font color="#000000">Occupation</font></b></td>
  <td width="64" align="center"><b><font color="#000000">Address</font></b></td>
  <td width="27" align="center"><b><font color="#000000">Age</font></b></td>
  <td width="50" align="center"><b><font color="#000000">Gender</font></b></td>
  <td width="58" align="center"><b><font color="#000000">Email</font></b></td>
  <td width="61" align="center"><b><font color="#000000">Phone</font></b></td>
  <td width="90" align="center"><b><font color="#000000">Description</font></b></td>
  <td></td>
</tr>
<?php
  $sql3="select * from client";
  $result3=mysql_query($sql3);
  
  $i=0;
  while($row=mysql_fetch_array($result3))
  {
	  ?>
<tr>
  <td align="center"><?php echo $row['clid'];?></td>
  <td align="center"><?php echo $row['clname'];?></td>
  <td align="center"><?php echo $row['cloccu'];?></td>
  <td align="center"><?php echo $row['claddrs'];?></td>
  <td align="center"><?php echo $row['clage'];?></td>
  <td align="center"><?php echo $row['clgen'];?></td>
  <td align="center"><?php echo $row['clemail'];?></td>
  <td align="center"><?php echo $row['clphone'];?></td>
  <td align="center"><?php echo $row['cldescr'];?></td>
  <td width="68" align="center"><a href="admin.php?view=client&flag=delete&id=<?php echo $row['clid'];?>"><img src="images/drop.png" width="35" height="35" border="0" title="Delete"/></a>
  <?php
		 
		 $i++;
		 ?>
</tr>
<?php
  }
  ?>
</table>
</body>
</html>