<?php
session_start();
require_once('phpfiles/connection.php');
$user=$_SESSION['admin']['username'];


$sql2="select * from manager";
$result2=mysql_query($sql2) or die(mysql_error());
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

 <table width="100%" border="0">
                   <tr align="center" bgcolor="#c01e46">
                      <td width="10%"><strong><font color="#FFFFFF">Manager</font></strong></td>
                      <td width="22%"><strong><font color="#FFFFFF">Project Topic</font></strong></td>
                      <td width="14%"><strong><font color="#FFFFFF">Completion Date</font></strong></td>
                      <td width="19%"><strong><font color="#FFFFFF">Work Status</font></strong></td>
                      <td width="35%"><strong><font color="#FFFFFF"></font></strong></td>
                     
                    </tr>
                    <?php
					while($row2=mysql_fetch_array($result2))
					{
						 $mgrcode=$row2['mgrcode'];
						 $sql0="select * from managerwork where mgrcode='$mgrcode'";
						$result10=mysql_query($sql0)or die(mysql_error());
						
						while($row10=mysql_fetch_array($result10))
						{
							$workid=$row10['projecttopic'];
							$sql8="select * from adminwork  where  workid='$workid'";
							$result8=mysql_query($sql8);
							$row8=mysql_fetch_array($result8);
												
					?>
                    <tr>
                      <td align="center"><?php echo $row2['mgrname']; ?></td>
                      <td align="center"><a href="<?php echo $row10['project']; ?>" target="_blank"><?php echo $row8['projecttopic']; ?></a> </td>
                      <td align="center"> <?php echo $row10['completiondate']; ?></td>
                      <td align="center"><?php echo $row10['workstatus']; ?></td>
                      <td><?php if($row10['workstatus']=="Complete"){ ?>Work Done Date :  <?php echo $row10['workdonedate']; ?><br />
                      <a href="<?php echo $row10['work']; ?>" target="_blank">Download Work</a><?php }?>
                      </td>
                    </tr>
                    <?php
					}}
					?>
                  </table>
</body>
</html>