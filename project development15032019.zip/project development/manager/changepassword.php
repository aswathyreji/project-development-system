<?php
session_start();
require_once("phpfiles/connection.php");
 $user=$_SESSION['manager']['username'];

$sql2="select * from login where username='$user'";
$result2=mysql_query($sql2);
$row2=mysql_fetch_array($result2);

$password=$row2['password'];

if($_POST['button'])
{

$currentpass=$_POST['currentpass'];
$newpass=$_POST['newpass'];
$confirmpas=$_POST['confirmpass'];

if($password==$currentpass)
{
	if($newpass==$confirmpas)
	{
		$sql="update login set password='$newpass' where username='$user'";	
		mysql_query($sql) or die(mysql_error());
		
		echo "<script>alert('Password Change Success')</script>";
		echo "<script>window.location='manager.php?view=changepassword'</script>";
	}
	else
	{
		echo "<script>alert('New password and Confirm password does not match')</script>";
		echo "<script>window.location='manager.php?view=changepassword'</script>";
	}
}
else
{
	echo "<script>alert('Current password does not match')</script>";
	echo "<script>window.location='manager.php?view=changepassword'</script>";
}
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

  <form id="form1" name="form1" method="post" action="">
  <div class="table">
    <table width="72%" height="199" border="0" align="center">
      <tr>
        <td width="50%">Current Password</td>
        <td width="50%"><input type="password" name="currentpass" id="currentpass" style="width:200px;" /></td>
      </tr>
      <tr>
        <td>New Password</td>
        <td><input type="password" name="newpass" id="newpass" style="width:200px;" /></td>
      </tr>
      <tr>
        <td>Confirm Password</td>
        <td><input type="password" name="confirmpass" id="confirmpass" style="width:200px;" /></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td><input type="submit" name="button" id="button" value="SUBMIT" class="formbutton" />
          <input type="reset" name="button2" id="button2" value="RESET" class="formbutton" /></td>
      </tr>
    </table>
    </div>
    <br />
  </form>

</body>
</html>