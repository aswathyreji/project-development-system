<?php
session_start();
require_once('phpfiles/connection.php');
$user=$_SESSION['username'];
$sql="select * from manager where username='$user'";
$result=mysql_query($sql)or die(mysql_error());
$row=mysql_fetch_array($result);
$userid=$row['mgrcode'];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<script src="validation/gen_validatorv31.js" type="text/javascript"></script>

</head>
<body>
<form action="#" method="post" enctype="multipart/form-data" name="addteamleader" onsubmit="return Validate()">
<table align="center" width="60%" border="0" cellspacing="5" cellpadding="1">
  <caption>
  <h2 align="left"><font color="#660000"><u>ADD TEAM LEADER </u></font></h2>
  </caption>
  <tr>
    <th  width="29%" align="left">Team Code</th>
    <th width="2%" align="left">:</th>
    <td width="69%" align="left"><input id="tcode"  name="tcode" type="text" size="25" />
    </td>
  </tr>
  <tr>
     <th align="left">Name</th>
    <th align="left">:</th>
	  <td align="left"><input name="tname" id="tname" type="text" size="25" /></td>
    </tr>
  <tr>
     <th align="left">Domain</th>
    <th align="left">:</th>
	  <td align="left"><input name="tdomain" id="tdomain" type="text" size=25/></td>
  </tr>
  <tr>
     <th align="left">Upload Photo</th>
    <th align="left">:</th>
	  <td align="left"><input name="tphoto" id="tphoto" type="file" /></td>
  </tr>
  <tr>
       <th align="left">Upload Resume</th>
    <th align="left">:</th>
	  <td align="left"><input name="tresume" id="tresume" type="file" /></td>
  </tr>
  <tr>
      <th align="left">Experience</th>
    <th align="left">:</th>
    <td align="left">
    <select name="texp" id="texp">
    <option value="select" selected="selected"><b>---SELECT---</b></option>
<option value="0to1"><b>0-1 Year</b></option>
<option value="1to2"><b>1-2 Year</b></option>
<option value="2to4"><b>2-4 Year</b></option>
<option value="morethan5"><b>More Than 5 Year</b></option>
		</select></td>
  <tr>
    <th align="left">Posted Date</th>
    <th align="left">:</th>
<td align="left"><div align="left"> <span class="style2">
        <input name="event_Date" type="text" id="event_Date"  class="textbox_slim" size="10" maxlength="13"  value="<?php echo $date;?>"  readonly="true" />
        </span>
        <input type="button" name="Button" value="..." class="pagefooter" onclick="displayCalendar(document.getElementById('event_Date'),'yyyy-mm-dd',this); "  title="click here to view calender" />
      </div>
</td>  </tr>
  <tr>
    <th align="left">Email</th>
    <th align="left">:</th>
    <th align="left"><input name="temail"  id="temail" type="text" size="25" /></th>
  </tr>
  <tr>
    <th align="left">Username</th>
    <th align="left">:</th>
	  <td align="left"><input name="tuname"  id="tuname" type="text" size=25/></td>
  </tr>
  <tr>
    <th align="left">Password</th>
    <th align="left">:</th>
	  <td align="left"><input name="tpass"  id="tpass" type="password" size=25/></td>
  </tr>
  <tr>
    <th align="left">Confirm Password</th>
    <th align="left">:</th>
	  <td align="left"><input name="tconpass" id="tconpass" type="password" size=25/></td>
  </tr>
  <tr>
  	<th align="left">&nbsp;</th>
    <th align="left">&nbsp;</th>
    <td align="left">&nbsp;</td>
  </tr>
  <tr>
  	<th align="left">&nbsp;</th>
    <th align="left">&nbsp;</th>
  	<td align="left"><input name="submit" type="submit" value="SUBMIT"/>&nbsp;&nbsp;<input name="reset" type="reset" value="RESET"/></td>
   </tr>
</table>
<?php
if($_POST['submit'])
{
	$teamcode=$_POST['tcode'];
    $teamname=$_POST['tname'];
	$teamdomain=$_POST['tdomain'];
	$iname=$_FILES['tphoto']['name'];
	$itype=$_FILES['tphoto']['type'];
	$itmpname=$_FILES['tphoto']['tmp_name'];
	$irid=rand();
	$iname=$irid.$iname;
	$ipath="manager/uploads/".$iname;
	if(($itype=='image/jpeg')||($itype=='image/jpg'))
		{
		move_uploaded_file($itmpname,$ipath);
		}
	$rname=$_FILES['tresume']['name'];
	$rtype=$_FILES['tresume']['type'];
	$rtmpname=$_FILES['tresume']['tmp_name'];
	$rrid=rand();
	$rname=$rrid.$rname;
	$rpath="manager/uploads/".$rname;
	if(($rtype=='application/pdf')||($rtype=='application/vnd.openxmlformats-officedocument.wordprocessingml.document')||($rtype=='application/msword'))
		{
		move_uploaded_file($rtmpname,$rpath);
		}
	$teamexp=$_POST['texp'];
	$teamdate=$_POST['tdate'];
	$teamemail=$_POST['temail'];
	$teamuname=$_POST['tuname'];
	$teampass=md5($_POST['tpass']);
	$teamconpass=$_POST['tconpass'];
	
	
	$sql="insert into teamleader values('','$userid','$teamcode','$teamname','$teamdomain','$teamuname','$ipath','$rpath','$teamexp','$teamdate','$teamemail')";
mysql_query($sql);

	$sql1="insert into login values('','teamleader','$teamuname','$teampass','1','0','$teamemail')";
mysql_query($sql1);
echo "<script>alert('Team leader added')</script>";
}
?>


</form>
<script  language="javascript" type="text/javascript">
	
function Validate() 
{
var code=document.addteamleader.tcode .value;  
  
if (code==null || code=="")
{  
  alert("Pls enter the code");  
  return false;  
}

if(document.addteamleader.tname.value=="")
{
alert("Pls enter Your name ");
return false;
}
else
{
if (!document.addteamleader.tname.value.match(/^[a-zA-Z]+$/)) 
   {
        alert('Only alphabets are allowed');
        return false;   
   }
}
if (document.addteamleader.tdomain.value == "")
{
alert(" Pls enter the domain");
return false;
}
var fileInput = document.getElementById('tphoto');
var filePath = fileInput.value;
var allowedExtensions = /(\.jpg|\.jpeg|\.png|\.gif)$/i;
if(document.addteamleader.tphoto.value=="")
{
alert("Pls enter teamleader photo ");
return false;
}
	else 
	{
		if(!allowedExtensions.exec(filePath))
	{
        alert('Please upload file having extensions .jpeg/.jpg/.png/.gif only.');
        fileInput.value = '';
        return false;
    }
	}

var fileInput = document.getElementById('tresume');
    var filePath = fileInput.value;
    var allowedExtensions = /(\.doc|\.docx|\.pdf)$/i;
if(document.addteamleader.tresume.value=="")
{
alert("Pls enter teamleader resume ");
return false;
}
	else
	{
    if(!allowedExtensions.exec(filePath))
	{
        alert('Please upload file having extensions .doc/.docx/.pdf only.');
        fileInput.value = '';
        return false;
	}
	}
if(document.addteamleader.texp.selectedIndex==0)
{ 
alert("Please select Experience");
return false;
}
	
if(document.addteamleader.event_Date.value=="")
{
alert("Pls enter posting date ");
return false;
}
var email = document.getElementById('temail');
var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
if(document.addteamleader.temail.value=="")
{
alert("Pls enter teamleader email ");
return false;
}
	else{
	
if (!filter.test(email.value)) {
    alert('Please provide a valid email address');
    email.focus;
    return false;
}
}
if (document.addteamleader.tuname.value == "")
{
alert(" Pls enter the username");
return false;
}
var password=document.addteamleader.tpass.value;  
  
if (password==null || password=="")
{  
  alert("Pls enter the password");  
  return false;  
}
else if(password.length<8)
{  
  alert("Password must be at least 8 characters long.");  
  return false;  
  } 
var password=document.addteamleader.tconpass.value;  
  
if (password==null || password=="")
{  
  alert("Pls enter the conform password");  
  return false;  
}
else 
{
	if(password.length<8)
{  
  alert("Password must be at least 8 characters long.");  
  return false;  
  } 
}
var password = document.getElementById("tpass").value;
var confirmPassword = document.getElementById("tconpass").value;
	
if (password != confirmPassword) {
alert("Passwords do not match.");
return false;
}
return true;
}
</script> 
</body>
</html>