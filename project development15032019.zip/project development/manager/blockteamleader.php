<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<body>

<?php
require_once('phpfiles/connection.php');
$user=$_SESSION['username'];
$sqla="select * from manager where username='$user'";
$resulta=mysql_query($sqla)or die(mysql_error());
$rowa=mysql_fetch_array($resulta);
$userid=$rowa['mgrcode'];

$flag=$_REQUEST['flag'];
$teamid=$_REQUEST['id'];
if($flag=='block')
{
	$sql1="select * from teamleader where teamid='$teamid'";
  $result1=mysql_query($sql1);
 $row1=mysql_fetch_array($result1);
 $uname1=$row1['username'];
 $sql2="update login set status='2' where username='$uname1'";
 mysql_query($sql2);
}
else if($flag=='unblock')
{
	$sql3="select * from teamleader where teamid='$teamid'";
  $result3=mysql_query($sql3);
 $row3=mysql_fetch_array($result3);
 $uname1=$row3['username'];
 $sql4="update login set status='1' where username='$uname1'";
 mysql_query($sql4);
}
if($flag=='delete')
{
 $sql5="select username from teamleader where teamid='$teamid'";
  $result5=mysql_query($sql5);
 $row5=mysql_fetch_array($result5);
 $username=$row5['username'];
 $sql6="delete from teamleader where teamid='$teamid'";
  mysql_query($sql6);
 $sql5="delete from login where username='$username'";
  mysql_query($sql5);
}
?>

<table width="682" border="0" align="center" cellpadding="3" cellspacing="0">
<tr>
  <td width="36">&nbsp;</td>
  <td width="103">&nbsp;</td>
  <td width="101">&nbsp;</td>
  <td width="80">&nbsp;</td>
  <td width="121">&nbsp;</td>
  <td width="90">&nbsp;</td>
  <td width="106">&nbsp;</td>
</tr>
<caption>
<h2><font color="#660000">TEAM LEADERS</font></h2>
</caption>
  <tr bgcolor="#CC6666">
    <td align="center"><b><font color="#000000">Sl No</font></b></td>
    <td align="center"><b><font color="#000000">Team Code</font></b></td>
    <td align="center"><b><font color="#000000">Team Name</font></b></td>
    <td align="center"><b><font color="#000000">Domain</font></b></td>
    <td align="center"><b><font color="#000000">Photo</font></b></td>
    <td align="center"><b><font color="#000000">Email</font></b></td>
  </tr>
  
  <?php
  $sql="select * from teamleader where mgrcode='$userid'";
  $result=mysql_query($sql);
  
  $i=0;
  while($row=mysql_fetch_array($result))
  {
	  $uname=$row['username'];
	  $sql1="select * from login where username='$uname'";
  $result1=mysql_query($sql1);
  $row1=mysql_fetch_array($result1);
  $status=$row1['status'];
	  ?>
	  <tr>
	     <td align="center"><?php echo $row['teamid'];?></td>
		 <td align="center"><?php echo $row['teamcode'];?></td>
		 <td align="center"><?php echo $row['teamname'];?></td>
		 <td align="center"><?php echo $row['teamdomain'];?></td>
		 <td align="center"><img src="<?php echo $row['teamphoto'];?>" width="80" height="80"/></td>
		 <td align="center"><?php echo $row['teamemail'];?></td>
		 <td align="center"><?php if($status=='1')
		 {
			 ?>
		 <a href="manager.php?view=blockteamleader&flag=block&id=<?php echo $row['teamid'];?>"><font color="#FF0000"><b><h2>Block</h2></b></font></a>
         <?php
		 }
		 else if($status=='2')
		 {
			 ?>
         <a href="manager.php?view=blockteamleader&flag=unblock&id=<?php echo $row['teamid'];?>"><font color="#006600"><b><h2>Unblock</h2></b></font></a><?php } ?></td> 
         <td width="95" align="center"><a href="manager.php?view=editleader&mid=<?php echo $row['teamid'];?>"><b><font color="#FF0000"><h2>Edit</h2></font></b></a></td>
   <td width="96" align="center"><a href="manager.php?view=blockteamleader&flag=delete&id=<?php echo $row['teamid'];?>"><font color="#FF0000"><b><h2>Delete</h2></b></font></a>
  <?php
		 
		 $i++;
		 ?>
  </tr>
  <?php
  }
  ?>
 </table>
 
 

</body>
</html>