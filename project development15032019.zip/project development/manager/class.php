<?php
class demo
{
	function demo()
	{
		switch($_REQUEST['view'])
		{
			case teamleader:
				include_once("manager/teamleader.php");	
				break;
			case employee:
				include_once("manager/employee.php");
				break;
				case blockteamleader:
				include_once("manager/blockteamleader.php");
				break;
				case blockemployee:
				include_once("manager/blockemployee.php");
				break;
				case asstoteam:
				include_once("manager/asstoteam.php");
				break;
				case mgrleaderworkstatus:
				include_once("manager/mgrleaderworkstatus.php");
				break;
				case managerworkstatus:
				include_once("manager/managerworkstatus.php");
				break;
				case sendmessage:
				include_once("manager/sendmessage.php");
				break;
				case inbox:
				include_once("manager/inbox.php");
				break;
				case sentbox:
				include_once("manager/sentbox.php");
				break;
				case editleader:
				include_once("manager/editleader.php");
				break;
				case editemployee:
				include_once("manager/editemployee.php");
				break;
				case changepassword:
				include_once("manager/changepassword.php");	
				break;
				case completed_wrk:
				include_once("manager/completed_wrk.php");	
				break;
		}
	}
	
}