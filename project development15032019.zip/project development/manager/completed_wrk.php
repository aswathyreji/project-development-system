<?php
require_once('phpfiles/connection.php');
$user=$_SESSION['manager']['username'];
$sql0="select mgrcode from manager where username='$user'";
$result0=mysql_query($sql0)or die(mysql_error());
$row0=mysql_fetch_array($result0);
$mgrcode=$row0['mgrcode'];

$sql="select * from managerwork where mgrcode='$mgrcode' and status='3'";
$result=mysql_query($sql)or die(mysql_error());
?>
<html>
<head>
<title></title>
</head>
<body>
<h1><font color="#FF6600"> &nbsp;>>STATUS OF PROJECTS</font></h1>
<table width="628" height="85" border="1"  bordercolor="#999999" align="center">
  <tr>
        <td colspan="6" align="center" bgcolor="#333333"><font color="#FFFFFF"><h2>Completed projects</h2></font></td>
  </tr>
  <tr>
  <td width="204" align="center"><font color="#000000"><b>Project topic</b></font></td>
  <td width="250" align="center"><font color="#000000"><b>Extra</b></font></td>
  <td width="248" align="center"><font color="#000000"><b>Given Completion date</b></font></td>
  <td width="150" align="center"><font color="#000000"><b>Assigned Teamleader</b></font></td>
  <td width="148" align="center"><font color="#000000"><b>Work done date</b></font></td>
    <td width="148" align="center"><font color="#000000"><b>Download</b></font></td>

  </tr>
 <?php
  $i=0;
  while($row=mysql_fetch_array($result))
  {
	   $pr=$row['projecttopic'];
    $sql0="select * from adminwork where workid='$pr'";
	$result0=mysql_query($sql0)or die(mysql_error());
	$row0=mysql_fetch_array($result0);
    $prj=$row0['projecttopic'];
	  
	  $sql3="select * from teamwork where projecttopic='$pr'";
  $result3=mysql_query($sql3);
  $row3=mysql_fetch_array($result3);
  $teamcode=$row3['teamcode'];
  
   $sql4="select * from teamleader  where teamcode='$teamcode'";
  $result4=mysql_query($sql4);
  $row4=mysql_fetch_array($result4);
	  ?>
<tr>
  <td height="22" align="center"><a href="<?php echo $row['project']; ?>" target="_blank"><?php echo $prj;?></a></td>
  <td align="center"><?php echo $row0['extra'];?></td>
  <td align="center"><font color="#FF0000"><?php echo $row['completiondate'];?></font></td>
    <td align="center"><?php echo $row4['teamname'];?></td>
    <td align="center"><font color="#FF0000"><?php echo $row['workdonedate'];?></font></td>
  <td height="22" align="center"><a href="<?php echo $row['work']; ?>" target="_blank">Download</a></td>
  
 <?php
		 
		 $i++;
		 ?>
</tr>
<?php
  }
  ?>
</table>
<br><br>

<table width="628" height="85" border="1"  bordercolor="#999999" align="center">
  <tr>
 <td colspan="5" align="center" bgcolor="#333333"><font color="#FFFFFF"><h2>Failed projects</h2></font></td>
  </tr>
  <tr>
  <td width="204" align="center"><font color="#000000"><b>Project topic</b></font></td>
  <td width="150" align="center"><font color="#000000"><b>Extra</b></font></td>
  <td width="248" align="center"><font color="#000000"><b>Given Completion date</b></font></td>
  <td width="150" align="center"><font color="#000000"><b>Assigned Teamleader</b></font></td>
  <td width="248" align="center"><font color="#000000"><b>Date given to Teamleader</b></font></td>
  </tr>
 <?php
  $sql="select * from managerwork where mgrcode='$mgrcode' and status='2'";
  $result=mysql_query($sql);
  
  $i=0;
  while($row=mysql_fetch_array($result))
  {
	  $pr=$row['projecttopic'];
    $sql0="select * from adminwork where workid='$pr'";
	$result0=mysql_query($sql0)or die(mysql_error());
	$row0=mysql_fetch_array($result0);
    $prj=$row0['projecttopic'];
	 
   
  $sql3="select * from teamwork where projecttopic='$pr'";
  $result3=mysql_query($sql3);
  $row3=mysql_fetch_array($result3);
  $teamcode=$row3['teamcode'];
  
   $sql4="select * from teamleader  where teamcode='$teamcode'";
  $result4=mysql_query($sql4);
  $row4=mysql_fetch_array($result4);
 
	  ?>
<tr>
  <td height="22" align="center"><a href="<?php echo $row['project']; ?>" target="_blank"><?php echo $prj;?></a></td>
  <td align="center"><?php echo $row3['extra'];?></td>
  <td align="center"><font color="#FF0000"><?php echo $row['completiondate'];?></font></td>
  <td align="center"><?php echo $row4['teamname'];?></td>
  <td align="center"><font color="#FF0000"><?php echo $row3['completiondate'];?></font></td>
 <?php
		 
		 $i++;
		 ?>
</tr>
<?php
  }
  ?>
</table>


</body>
</html>