<?php
require_once('phpfiles/connection.php');
$user=$_SESSION['manager']['username'];

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<p>
  <?php
  $from_id=$user." - manager";
$sql="select * from sentitems where from_id='$from_id'";
$result=mysql_query($sql)or die(mysql_error());
?>
</p>
<p>&nbsp; </p>
<form action="#" method="post" name="inbox" enctype="multipart/form-data">
  <table width="681" height="62" border="0" align="center">
  <tr>
    <td height="34" colspan="4" bgcolor="#330000"><font color="#FFFFFF"><img src="images/sentbox.png" width="100" height="100"/><h2 align="center">SENTBOX</h2></font></td>
  </tr>
  <?php while($row=mysql_fetch_array($result))
{?>
	<tr bgcolor="#FFCC33">
    <td width="126" height="22"><font color="#000000">To:</font><?php echo $row['to_id'];?></td>
    <td width="110"><font color="#000000"> Subject:</font><?php echo $row['subject'];?></td>
    <td width="331"><font color="#000000"> Message:</font><?php echo $row['message'];?></td>
    <td><a href="<?php echo $row['attachment']; ?>" target="_blank"><font color="#FF0000">click to download attachment</font></a></td></tr>
   <?php 
	
}
?>  
</table>
 <input name="delete" type="submit" value="CLEAR SENTBOX"/> 
<?php
if($_POST['delete'])
{
	
	$sql="delete from sentitems where from_id='$from_id'";
	mysql_query($sql);
	echo "<script>alert('Sentbox cleared')</script>";
	echo "<script>window.location='manager.php?view=sentbox'</script>";
}
?>
</form>

</body>
</html>