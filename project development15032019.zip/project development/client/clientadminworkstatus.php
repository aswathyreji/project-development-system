<?php
session_start();
require_once('phpfiles/connection.php');
$user=$_SESSION['client']['username'];


$sql2="select * from client where username='$user'";
$result2=mysql_query($sql2) or die(mysql_error());
$row2=mysql_fetch_array($result2);
$userid=$row2['clid'];
$sql3="select * from adminwork  where userid='$userid' ";
$result3=mysql_query($sql3) or die(mysql_error());
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

 <table width="100%" border="0">
                   <tr align="center" bgcolor="#c01e46">
                     
                      <td width="42%"><strong><font color="#FFFFFF">Project Topic</font></strong></td>
                      <td width="14%"><strong><font color="#FFFFFF">Completion Date</font></strong></td>
                      <td width="19%"><strong><font color="#FFFFFF">Work Status</font></strong></td>
                      <td width="35%"><strong><font color="#FFFFFF"></font></strong></td>
                     
                    </tr>
                    <?php
					while($row3=mysql_fetch_array($result3))
					{
						 					
					?>
                    <tr height="40px">
                      <td align="center"><a href="<?php echo $row3['project']; ?>" target="_blank"><?php echo $row3['projecttopic']; ?></a> </td>
                      <td align="center"> <?php echo $row3['completiondate']; ?></td>
                      <td align="center"><?php echo $row3['workstatus']; ?></td>
                      <td><?php if($row3['workstatus']=="Complete"){ ?>Work Done Date :  <?php echo $row3['workdonedate']; ?><br />
                      <a href="<?php echo $row3['work']; ?>" target="_blank">Download Work</a><?php }?>
                      </td>
                    </tr>
                    <?php
					}
					?>
                  </table>
</body>
</html>