<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
    <h1><font color="#990099">DEVELOPERS</font></h1><br />
     
    
     <p> <font color="#FF0066"><strong>Rahulraj D. <br />
ph:+919895106740,</strong><strong><br />
email:rahulayoor007@gmail.com</strong><strong><br /></p>
<p><font color="#FF0066"><strong>Alen T. Daniel <br />
ph:+919947086465,</strong><strong><br />
email:alentdaniel@gmail.com</strong><strong><br /></p>
<p><font color="#FF0066"><strong>Aneesh S. <br />
ph:+919746173268,</strong><strong><br />
email:aneeshvynm@gmail.com</strong><strong><br /></p>
<p><font color="#FF0066"><strong>Arun S. <br />
ph:+918129674544,</strong><strong><br />
email:arunsajeev99@gmail.com</strong><strong><br /></p>
</body>
</html>