<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Home page - project scrutinizer</title>
</head>

<body>
<!-- <table width="925" border="0">
          <tr>
            <td><div class="col_allw280">
              <p>The objective of the system is providing a web application for a software company for supporting the planning of human resources and project management. Resource planning is a key to success of any project. The main concepts of the system are tasks on one hand and employees on the other hand. Tasks need to be completed in a certain time by a limited amount of employees with specific skills. The system supports the process of associating tasks to the right employees in a way that due dates are met while every employee gets a constant workload and also the work of each of the employee can be analyzed efficiently.  </p>
            </div>
              <div class="col_allw280">
                <h3>Services</h3>
                <p>The software being developed has the following features:</p>
               
                <ul class="tmo_list">
                  <li> the system is being developed with the user friendly uis. </li>
                  <li>various authentication and access levels are handled.</li>
                  <li>information files about the employees, clients, and other users can be stored in a centralized database. </li>
                </ul>
                <div class="cleaner"></div>
              </div><div class="col_allw280 col_last">
                <h3>News Updates</h3>
                <br /><table width="100%" height="290" border="0">
  <tr>
    <td align="left" valign="top"><marquee direction="up" scrolldelay="80" scrollamount="1" onmouseover="this.stop();" onmouseout="this.start();" height="280px"><p align="justify"><?php echo $rown['news']; ?></p></marquee></td>
  </tr>
</table>
              </div>
            <div class="cleaner"></div></td>
          </tr>
        </table>-->
                
                
                	<h1>PROJECT MANAGEMENT MADE EASY !</h1>
               	  <p><img alt="Image" src="images/templatemo_image.jpg" />              <p>Our objective is to provide help for supporting the planning of human resources and project management. Resource planning is a key to success of any project. Our main concepts are tasks on one hand and employees on the other hand. Tasks need to be completed in a certain time by a limited amount of employees with specific skills. The system supports the process of associating tasks to the right employees in a way that due dates are met while every employee gets a constant workload and also the work of each of the employee can be analyzed efficiently.  </p>
</p>
<br /><br /><h2><p><font color="#CC3399">=>KEY FEATURES AND BENIFITS</font></p></h2>
           	  <div id="templatemo_bottom_section">
                    	<div class="templatemo_bottom_section_box">
                        	<h2>PROJECT MANAGEMENT</h2>
                            <img alt="company" src="images/templatemo_image_1.jpg" />
                       	  <p><h3>Managing projects online</h3></p>
							No matter how big or small a project, Project scrutinizer will help you take control!
        </div>
                        
                        <div class="templatemo_bottom_section_box">
                        	<h2>BETTER COMMUNICATION</h2>
                            <img alt="company" src="images/templatemo_image_2.jpg" />
                     		<p><h3>Messaging and chatting</h3></p>
							Help your team communicate with messages! Group them in specific categories to find them fast!
                        </div>
                        
                        <div class="templatemo_bottom_section_box">
                        	<h2>TIME TRACKING</h2>
                          <img alt="products"  src="images/templatemo_image_3.jpg" /><br />
                         <p><h3>Efficiant time management</h3></p>
						 Project scrutinizer allows you to easily track both normal and billable time on your projects!
             
			 </div>
                        
                  </div>
</body>
</html>