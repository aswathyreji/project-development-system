<?php
class demo
{
	function demo()
	{
		switch($_REQUEST['view'])
		{
			case project:
				include_once("client/addproject.php");	
				break;
			case clientadminworkstatus:
				include_once("client/clientadminworkstatus.php");	
				break;
			case sendmessage:
				include_once("client/sendmessage.php");	
				break;
			case inbox:
				include_once("client/inbox.php");
				break;
			case sentbox:
				include_once("client/sentbox.php");
				break;
			case changepassword:
				include_once("client/changepassword.php");	
				break;
			
			case about:
				include_once("client/about.php");	
				break;
			case contact:
				include_once("client/contact.php");	
				break;
			
		}
	}
	
}