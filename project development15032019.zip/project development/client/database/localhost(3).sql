-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 11, 2013 at 10:57 AM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `scrutinizer`
--
CREATE DATABASE `scrutinizer` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `scrutinizer`;

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE IF NOT EXISTS `employee` (
  `empid` int(6) NOT NULL AUTO_INCREMENT,
  `teamcode` varchar(20) NOT NULL,
  `empcode` varchar(20) NOT NULL,
  `empname` varchar(20) NOT NULL,
  `teamname` varchar(20) NOT NULL,
  `empphoto` varchar(100) NOT NULL,
  `empresume` varchar(100) NOT NULL,
  `empexp` varchar(10) NOT NULL,
  `empdate` date NOT NULL,
  `empemail` varchar(20) NOT NULL,
  `empproject` varchar(50) NOT NULL,
  PRIMARY KEY (`empid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `loginid` int(6) NOT NULL AUTO_INCREMENT,
  `user` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL,
  `online` int(6) NOT NULL,
  `email` varchar(20) NOT NULL,
  PRIMARY KEY (`loginid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`loginid`, `user`, `username`, `password`, `status`, `online`, `email`) VALUES
(1, '', 'admin', 'admin', 'admin', 0, 'admin@gmail.com'),
(6, '', '', '', 'employee', 0, ''),
(7, 'tdgf', 'dtgh', 'dgdrt', 'employee', 0, 'dgdg');

-- --------------------------------------------------------

--
-- Table structure for table `manager`
--

CREATE TABLE IF NOT EXISTS `manager` (
  `mgrid` int(6) NOT NULL AUTO_INCREMENT,
  `mgrcode` varchar(20) NOT NULL,
  `mgrname` varchar(20) NOT NULL,
  `mgrdomain` varchar(20) NOT NULL,
  `mgrphoto` varchar(100) NOT NULL,
  `mgrresume` varchar(100) NOT NULL,
  `mgrexp` varchar(10) NOT NULL,
  `mgrdate` date NOT NULL,
  `mgremail` varchar(20) NOT NULL,
  PRIMARY KEY (`mgrid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Table structure for table `teamleader`
--

CREATE TABLE IF NOT EXISTS `teamleader` (
  `teamid` int(6) NOT NULL AUTO_INCREMENT,
  `teamcode` varchar(20) NOT NULL,
  `teamname` varchar(20) NOT NULL,
  `teamdomain` varchar(20) NOT NULL,
  `teamphoto` varchar(100) NOT NULL,
  `teamresume` varchar(100) NOT NULL,
  `teamexp` varchar(10) NOT NULL,
  `teamdate` date NOT NULL,
  `teamemail` varchar(20) NOT NULL,
  PRIMARY KEY (`teamid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `teamleader`
--

INSERT INTO `teamleader` (`teamid`, `teamcode`, `teamname`, `teamdomain`, `teamphoto`, `teamresume`, `teamexp`, `teamdate`, `teamemail`) VALUES
(1, '125', 'arun', 'aruns', '', '', '1to2', '0000-00-00', 'eefrseydrutyu');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
