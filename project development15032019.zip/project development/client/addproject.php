<?php
session_start();
require_once('phpfiles/connection.php');
$user=$_SESSION['client']['username'];
$sql="select * from client  where username='$user'";
$result=mysql_query($sql)or die(mysql_error());
$row=mysql_fetch_array($result);
$userid=$row['clid'];
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<script src="validation/gen_validatorv31.js" type="text/javascript"></script>
</head>

<body>
<form action="" method="post" name="adminwork" enctype="multipart/form-data">
<table width="75%" border="0" align="center" cellpadding="1" cellspacing="5">
  <caption>
    <h3 align="left"><u>ADD PROJECT DETAILS</u></h3>
  </caption>
  <tr>
    <th width="21%" align="left">Project Topic</th>
    <th width="2%" align="left">:</th>
    <td width="77%" align="left"><input name="adtopic" type="text" size="25" maxlength="100" /></td>
  </tr>
  <tr>
    <th align="left">Project</th>
    <th align="left">:</th>
    <td align="left"><input name="clientproject" type="file" value="Upload abstract" /></td>
  </tr>
  <tr>
    <th align="left">Extra</th>
    <th align="left">:</th>
    <td align="left"><textarea name="adextra" cols="21" rows="5"></textarea></td>
  </tr>
  <tr>
    <th align="left">Completion Date</th>  
    <th align="left">:</th>
    <td align="left">
    <input name="addate" type="text" id="addate"  class="textbox_slim" size="10" maxlength="13"  value="<?php echo $date;?>"  readonly="true" />
    <input type="button" name="Button" value="..." class="pagefooter" onclick="displayCalendar(document.getElementById('addate'),'yyyy-mm-dd',this); "  title="click here to view calender" />
    
    <!--<input name="addate" type="text" value="YYYY/MM/DD" size="25" maxlength="10" />--></td>
  </tr>
   <tr>
    <th align="left">&nbsp;</th>
    <th align="left">&nbsp;</th>
    <th align="left">&nbsp;</th>
  </tr>
  <tr>
    <th align="left">&nbsp;</th>
    <th align="left">&nbsp;</th>
    <th align="left"><input name="submit" type="submit" value="SUBMIT" /><input name="reset" type="reset" value="RESET" /></th>
  </tr>
</table>
<?php
if($_POST['submit'])
{
	
   $projecttopic=$_POST['adtopic'];
	$rname=$_FILES['clientproject']['name'];
	$rtype=$_FILES['clientproject']['type'];
	$rtmpname=$_FILES['clientproject']['tmp_name'];
	$rrid=rand();
	$rname=$rrid.$rname;
	$rpath="client/uploads/".$rname;
	if(($rtype=='application/pdf')||($rtype=='application/vnd.openxmlformats-officedocument.wordprocessingml.document')||($rtype=='application/msword'))
		{
		move_uploaded_file($rtmpname,$rpath);
		}
	 $extra=$_POST['adextra'];
	 $completiondate=$_POST['addate'];
	

	$sql="insert into adminwork values('','$userid','$projecttopic','$rpath','$extra','$completiondate','','','unassigned','0')";
mysql_query($sql) or die(mysql_error());
}
?>
</form>
<script  language="javascript" type="text/javascript">
 
 var frmvalidator = new Validator("adminwork");
 frmvalidator.addValidation("adtopic","req","Please enter project topic");
 
 var frmvalidator = new Validator("adminwork");
 frmvalidator.addValidation("addate","req","Please select the completion date");
 
 
</script>

</body>
</html>