<?php
session_start();
require_once("phpfiles/connection.php");
 $user=$_SESSION['admin']['username'];
if($user=='')
{
	echo "<script>window.location='index.php'</script>";
}
else
{
	$log=$_REQUEST['log'];
	if($log=='logout')
	{
		mysql_query("update login set online=0 where username='$user'");
		unset($_SESSION['admin']);
		echo "<script>window.location='index.php'</script>";
	}
	
		//CHAT SECTION
	//$sname=$_SESSION['name'];
	$reschat=mysql_query("select * from login where online='1'");
$_SESSION['username'] = $user;
//CHAT SECTION CLOSE
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
<script language="javascript" type="text/javascript">
function clearText(field){

    if (field.defaultValue == field.value) field.value = '';
    else if (field.value == '') field.value = field.defaultValue;

}
</script>
<script type="text/javascript">
function onlinefn(val)
{
	
	var stat=document.getElementById("status").value;
	$.post("ajax_online.php",{status:stat,rid:val},function(data){
		
		});
}
</script>
<link rel="stylesheet" href="phpfiles/calendar/calendar.css" media="screen"></LINK>

<SCRIPT type="text/javascript" src="phpfiles/calendar/calendar.js?random=20060118"></script>
<link type="text/css" rel="stylesheet" media="all" href="css/chat.css" />
<link type="text/css" rel="stylesheet" media="all" href="css/screen.css" />
</head>
<body>
<!--  Free CSS Template by TemplateMo.com  --> 
	<div id="templatemo_background_section_top">
		<div class="templatemo_container">
			<div id="templatemo_header">
				<div id="templatemo_logo">
					<h1>Project Development</h1>
                   <h2 align="center"><font color="#FFFFFF">Welcome Administrator</font></h2>
				</div>
                <div id="templatemo_search_box">
                  <pre>                                  <a href="admin.php?log=logout"><img src="images/logout.png" width="70" height="20"/></a></pre>
				</div>
                <div id="templatemo_menu">
                	<div id="templatemo_menu_bg_l"></div>
                    <div id="templatemo_menu_bg_r">
                    	<ul>
    						<li class="current"><a href="admin.php" ><b>HOME</b></a></li>
        					<li><a href="admin.php?view=projectmanager"><b>ADD MANAGER</b></a></li>
        					<li><a href="admin.php?view=assignproject"><b>ASSIGN PROJECT</b></a></li>	
                            <li><a href="admin.php?view=adminmgrworkstatus"><b>MANAGER WORKS</b></a></li>	
                            <li><a href="admin.php?view=adminworkstatus"><b>MY WORKS</b></a></li>	
                           	
    					</ul>
                    </div>
                </div>
			</div><!--  End Of Header  -->
		</div><!--  End Of Container  -->        
        
	</div><!--  End Of Back Ground Section Top  -->
    
    <div id="templatemo_background_section_middle">
    
  <div class="templatemo_container">
			
            <div id="templatemo_content_area">
            	
                <div id="templatemo_left">
					<div class="templatemo_section">
                    
                    
                    
						<div class="templatemo_section_top_pc">
                        	<h2><font color="#FFFF00"><img src="images/message.png" width="40" height="30"  align="left"/> MESSAGES</font></h2>
	                   	</div>
						<div class="templatemo_section_middle">
						  <ul><br /><br />
                                <li><a href="admin.php?view=sendmessage"><b><font color="#FFFFFF">COMPOSE</font></b></a></li>
                                <li><a href="admin.php?view=inbox"><b><font color="#FFFFFF">INBOX</font></b></a></li>
                                <li><a href="admin.php?view=sentbox"><b><font color="#FFFFFF">SENTBOX</font></b></a></li>
                                
           	            	  	
                        	</ul>
                            
                                                          <h2><font color="#FFFF00"><img src="images/link.png" width="40" height="30"  align="left"/> LINKS</font></h2>

                             
                             
                             <ul>
                             	<li><a href="admin.php?view=completed_wrk"><b><font color="#FFFFFF">COMPLETED/FAILED PROJECTS</font></b></a></li>
                              	<li><a href="admin.php?view=blockmanager"><b><font color="#FFFFFF">MANAGERS</font></b></a></li>
                                <li><a href="admin.php?view=client"><b><font color="#FFFFFF">CLIENTS</font></b></a></li>
                                 <li><a href="admin.php?view=addnews"><b><font color="#FFFFFF">ADD NEWS</font></b></a></li>
                                 <li><a href="admin.php?view=changepassword"><b><font color="#FFFFFF">CHANGE PASSWORD</font></b></a></li>
                        	</ul>
                             <div class="cleaner_with_height"> </div> 
                	    </div>
                        
                        <div class="templatemo_section_bottom">
	                    </div>
                        
                        
                        
                           <div class="templatemo_section_top_pc">
                        	<h2><font color="#FFFF00"><img src="images/chat1.png" width="40" height="30"  align="left"/> CHAT</font></h2>
	                   	</div>
						<div class="templatemo_section_middle">
						
                         <br />
                         <br />
                          <table>
                           <tr><td>
                           <?php $statres=mysql_query("select * from login where username='$user'");
                            $statrow=mysql_fetch_array($statres);
                           
							   $id=$statrow['loginid'];
							 
                            ?>
                            <select name="status" class="status" id="status" style="width:160px;background-color:#FFD7D7" onChange="onlinefn(<?php echo $id;?>)">
                            <option value="">------Set Status Here------</option>
                            <?php $statres1=mysql_query("select online from login where username='$user'");
                            $statrow1=mysql_fetch_array($statres1);
                            $onlinestat=$statrow1['online'];
							  
                            ?>
                            <option <?php if($onlinestat=='0') {?> selected="selected"<?php }?>>offline</option>
                            <option <?php if($onlinestat=='1') {?> selected="selected"<?php }?>>online</option>
                            </select>
                            </td></tr>
                            <?php
                            while($rowchat=mysql_fetch_array($reschat))
                            {
                                $uname=$rowchat['username'];
                              //  $name=$rowchat['name'];
                                if($uname<>$user){
                                ?>
                                <tr><td><a href="javascript:void(0)" onClick="javascript:chatWith('<?php echo $uname;?>')">Chat With <?php echo $uname;?></a></td></tr>
                                <?php } }?>
                                <script type="text/javascript" src="js/jquery.js"></script>
                            <script type="text/javascript" src="js/chat.js"></script>
                                                      
                                        </table>  
                                        
                                        
                                        
                                     
                                        
                                        
                                                    
                           <div class="cleaner_with_height"> </div>
                	    </div>
                        
                    	<div class="templatemo_section_bottom">
	                    </div>
                        
                        
                        
					</div><!--  End Of Section--><!--  End Of Section-->
                
				</div><!--  End Of Left-->
                
                <div id="templatemo_right">
                	<?php
					if($_REQUEST['view']!="")
					{
						
						$classpath='admin/class.php';
						require_once($classpath);
						$classobj=new demo;
					}
					else
					{
						include_once('admin/home.php');
					}
					?>
              </div>
                        
                  </div><!-- End Of Bottom Panel-->
                </div><!-- End Of Right -->
                
          </div><!--  End Of Content Area-->
            
	  </div><!--  End Of Container-->    
        
	</div><!--  End Of Back Ground Section Middle  -->

    <div id="templatemo_background_section_bottom"> 
		<div class="templatemo_container">
       	  <div id="templatemo_footer_section">
       	    <div class="templatemo_footer_section_box">
                  <h2>Quick Contact</h2>
                  <p>Tel: +919895106740 </p>
                  
                  <div class="cleaner_with_height"></div>
            </div>
                <div class="templatemo_footer_section_box_2">
                	Copyright © 2018 scrutinizer <br />
                    
            </div>
          </div>
            
        </div>
    </div><!--  End Of Back Ground Section bottom  -->
</body>
<!--  Designed by w w w . t e m p l a t e m o . c o m  --> 
</html>
<?php
}
?>