<?php
session_start();
require_once("phpfiles/connection.php");
$user=$_SESSION['username'];
if($user=='')
{
	echo "<script>window.location='index.php'</script>";
}
else
{
	$log=$_REQUEST['log'];
	if($log=='logout')
	{
		session_destroy();
		echo "<script>window.location='index.php'</script>";
	}
	//CHAT SECTION
	//$sname=$_SESSION['name'];
	$reschat=mysql_query("select * from login where online='1'");
//$_SESSION['username'] = $sname;
//CHAT SECTION CLOSE
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<meta name="keywords" content="free css templates, business template, HTML CSS" />
<meta name="description" content="Business Template - Free CSS Templates by TemplateMo.com" />
<link href="templatemo_style.css" rel="stylesheet" type="text/css" />
<script language="javascript" type="text/javascript">
function clearText(field){

    if (field.defaultValue == field.value) field.value = '';
    else if (field.value == '') field.value = field.defaultValue;

}
</script>
<script type="text/javascript">
function onlinefn(val)
{
	var stat=document.getElementById("status").value;
	$.post("ajax_online.php",{status:stat,rid:val},function(data){
		
		});
}
</script>
</head>
<body>
<!--  Free CSS Template by TemplateMo.com  --> 
	<div id="templatemo_background_section_top">
		<div class="templatemo_container">
			<div id="templatemo_header">
				<div id="templatemo_logo">
					<h1>PROJECT SCRUTINIZER</h1>
                   <h2 align="center"><font color="#FFFFFF">Welcome <?php echo $user ?> (manager)</font></h2>
				</div>
                <div id="templatemo_search_box">
           	    	<form method="post" action="index.html">
                    <label>Search:</label>
                	  <input name="search" value="Search..." type="text" onfocus="clearText(this)" onblur="clearText(this)" />
                	  <input class="button" type="submit" name="Search" value="GO"/>
               	  	</form>
                     <pre>                                  <a href="admin.php?log=logout"><img src="images/logout.png" width="70" height="20"/></a></pre>
				</div>
                <div id="templatemo_menu">
                	<div id="templatemo_menu_bg_l"></div>
                    <div id="templatemo_menu_bg_r">
                    	<ul>
    						<li class="current"><a href="manager.php" ><b>HOME</b></a></li>
        					<li><a href="manager.php?view=teamleader"><b>ADD LEADER</b></a></li>
        					<li><a href="manager.php?view=employee"><b>ADD EMPLOYEE</b></a></li>	
        					<li><a href="manager.php?view=blockteamleader"><b>LEADER</b></a></li>	
                            <li><a href="manager.php?view=blockemployee"><b>EMPLOYEE</b></a></li>
                            <li><a href="manager.php?view=asstoteam"><b>ASSIGN</b></a></li>
    					</ul>
                    </div>
                </div>
			</div><!--  End Of Header  -->
		</div><!--  End Of Container  -->        
        
	</div><!--  End Of Back Ground Section Top  -->
    
    <div id="templatemo_background_section_middle">
    
  <div class="templatemo_container">
			
            <div id="templatemo_content_area">
            	
                <div id="templatemo_left">
					<div class="templatemo_section">
						<div class="templatemo_section_top_pc">
             <h2><font color="#FFFF00"><img src="images/message.png" width="40" height="30"  align="left"/> MESSAGES</font></h2>
	                   	</div>
						<div class="templatemo_section_middle">
							<ul><br /><br />
                                <li><a href="manager.php?view=sendmessage"><b><font color="#FFFFFF">COMPOSE</font></b></a></li>
                                <li><a href="manager.php?view=inbox"><b><font color="#FFFFFF">INBOX</font></b></a></li>
                                <li><a href="manager.php?view=sentbox"><b><font color="#FFFFFF">SENTBOX</font></b></a></li>
           	            	  	
                        	</ul>
						  <div class="cleaner_with_height">&nbsp;</div>
                	    </div>
                                                
                    	<div class="templatemo_section_bottom">
	                    </div>
                        
                        
                        
                        
                        
                        
                           <div class="templatemo_section_top_pc">
                        	<h2><font color="#FFFF00"><img src="images/chat1.png" width="40" height="30"  align="left"/> CHAT</font></h2>
	                   	</div>
						<div class="templatemo_section_middle">
						
                         <br />
                         <br />
                          <table>
                           <tr><td>
                           <?php $statres=mysql_query("select * from login where username='$user'");
                            $statrow=mysql_fetch_array($statres);
                            $onlinestat=$statrow['online'];
							  $id=$statrow['loginid	'];
                            ?>
                            <select name="status" class="status" id="status" style="width:160px;background-color:#FFD7D7" onChange="onlinefn(<?php echo $id;?>)">
                            <option value="">------Set Status Here------</option>
                            
                            <option <?php if($onlinestat=='0') {?> selected="selected"<?php }?>>offline</option>
                            <option <?php if($onlinestat=='1') {?> selected="selected"<?php }?>>online</option>
                            </select></td></tr>
                            <?php
                            while($rowchat=mysql_fetch_array($reschat))
                            {
                                $uname=$rowchat['username'];
                                $name=$rowchat['name'];
                                if($uname<>$sname){
                                ?>
                                <tr><td><a href="javascript:void(0)" onClick="javascript:chatWith('<?php echo $uname;?>')">Chat With <?php echo $uname;?></a></td></tr>
                                <?php } }?>
                                <script type="text/javascript" src="js/jquery.js"></script>
                            <script type="text/javascript" src="js/chat.js"></script>
                                                      
                                        </table>  
                                        
                                        
                                        
                                     
                                        
                                        
                                                    
                           <div class="cleaner_with_height"> </div>
                	    </div>
                        
                    	<div class="templatemo_section_bottom">
	                    </div>
                        
                        
                        
                        
                        
					</div><!--  End Of Section-->
                    <div class="templatemo_section">
						<div class="templatemo_section_top_pic">
                        	NEWS &amp; EVENTS
	                   	</div>
						<div class="templatemo_section_middle">
                        	<ul>
                                <li><a href="#">Lorem ipsum dolor sit amet</a></li>
                                <li><a href="#">Consectetur adipiscing elit</a></li>
                                <li><a href="#">Duis blandit pharetra dui</a></li>
           	            	  	<li><a href="#">Sed metus enim, volutpat at</a></li>
							</ul>
							<ul>
                                <li><a href="#">In fermentum tellus Proin </a></li>
                                <li><a href="#">Donec ut neque a magna </a></li>
                                <li><a href="#">Vivamus euismod. Donec </a></li> 
                                <li><a href="#">Etiam ut massa sed augue </a></li>
                        	</ul>
                            <div class="cleaner_with_height">&nbsp;</div>
                	    </div>
                    	<div class="templatemo_section_bottom">
	                    </div>
					</div><!--  End Of Section-->
                
				</div><!--  End Of Left-->
                
                <div id="templatemo_right">
                	<?php
					if($_REQUEST['view']!="")
					{
						
						$classpath='manager/class.php';
						require_once($classpath);
						$classobj=new demo;
					}
					else
					{
						include_once('manager/home.php');
					}
					?>
              </div>
                        
                  </div><!-- End Of Bottom Panel-->
                </div><!-- End Of Right -->
                
          </div><!--  End Of Content Area-->
            
	  </div><!--  End Of Container-->    
        
	</div><!--  End Of Back Ground Section Middle  -->

    <div id="templatemo_background_section_bottom"> 
		<div class="templatemo_container">
       	  <div id="templatemo_footer_section">
           	  <div class="templatemo_footer_section_box">
                   <p><a href="http://validator.w3.org/check?uri=referer">
     		       	<img height="31" alt="Valid XHTML 1.0 Transitional" src="http://www.w3.org/Icons/valid-xhtml10" width="88" vspace="8" border="0" />
				</a>
            	  <a href="http://jigsaw.w3.org/css-validator/check/referer">
            		<img alt="Valid CSS!" src="http://jigsaw.w3.org/css-validator/images/vcss-blue" vspace="8" border="0" />                 
                 </a></p>
           	  </div>
                <div class="templatemo_footer_section_box">
                  <h2>Quick Contact</h2>
                  <p>Tel: 000-100-1010</p>
                  <p>Fax: 000-200-2020</p>
                  <p>Email: info@yourcompany.com</p>
                  <div class="cleaner_with_height"></div>
                </div>
                <div class="templatemo_footer_section_box_2">
                	Copyright © 2018 scrutinizer<br />
                    <a href="http://www.iwebsitetemplate.com" target="_parent">Website Templates</a> by <a href="http://www.templatemo.com" title="Free CSS Templates" target="_parent">Free CSS Templates</a>
                </div>
          </div>
            
        </div>
    </div><!--  End Of Back Ground Section bottom  -->
</body>
<!--  Designed by w w w . t e m p l a t e m o . c o m  --> 
</html>
<?php
}
?>