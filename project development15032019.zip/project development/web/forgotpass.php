
<!--Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->

<? php
require_once('phpfiles/connection.php');
?>

<!DOCTYPE HTML>
<html>
<head>
<title>Reset Password </title>
<link href="css2/style.css" rel="stylesheet" type="text/css" media="all"/>
<!-- Custom Theme files -->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<meta name="keywords" content="Reset Password Form Responsive, Login form web template, Sign up Web Templates, Flat Web Templates, Login signup Responsive web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<!--google fonts-->
<!--<link href='//fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900' rel='stylesheet' type='text/css'>-->
</head>
<body>

<?php
if(isset($_POST["submit"]))
{
echo "<script >alert($_POST['email'])</script>";
$sql= mysql_query("select * from login where email='$email'");
$count=0;
while ($row = mysql_fetch_array($sql)) {

    $count++;
    $password=$row['password'];
}
if(count>0)
{
echo "<script >alert($count)</script>";
$to = $email;
$subject = "change password";
$txt = $password;
$headers = "From: abc@gmail.com" . "\r\n" .
"CC: somebodyelse@example.com";

mail($to,$subject,$txt,$headers);


}
else
{

echo "<script>alert('user not registered')</script>";
}
}
?>
<!--element start here-->
  <form action="" method="post">
<div class="elelment">
	<h2>Reset Password Form</h2>
	<div class="element-main">
		<h1>Forgot Password</h1>
		<p> change your Password</p>
			<input type="text" name="email" id="email" value="Your e-mail address" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Your e-mail address';}">
			<input type="submit"  name="submit" id="submit" value="Reset my Password">
		
	</div>
</div>
<div class="copy-right">
			<p>Copyright © 2019 Project Development </p>
</div>
</form>
<!--element end here-->
</body>
</html>