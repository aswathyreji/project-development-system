<?php
require_once('phpfiles/connection.php');
$user=$_SESSION['leader']['username'];
$sql0="select teamcode from teamleader where username='$user'";
$result0=mysql_query($sql0)or die(mysql_error());
$row0=mysql_fetch_array($result0);
$teamcode=$row0['teamcode'];

$sql="select * from teamwork where status='0' and teamcode='$teamcode'";
$result=mysql_query($sql)or die(mysql_error());
?>
<script type="text/javascript" src="phpfiles/jquery-1.4.js"></script>
<script type="text/javascript">
prjt=function()
{

	var vals=$("#prtopic").val();
	$.post("leader/projectleader.php",{prj:vals},function(data)
	{
		$(".ans").html(data);
		
	});
}
</script>
<script type="text/javascript">
 function datecheck(frmname)
{
  var frm = document.forms[frmname];
  if((frm.teamdate.value <= frm.empwdate.value))
  {
    alert('Completion date should be less than managers date');
	frm.mgrwdate.focus();
	    return false;
  }
  else
  {
  
        return true; 
  

  }
}
</script>







<form action="#" method="post" name="teamleaderwork" enctype="multipart/form-data" onsubmit="return datecheck('teamleaderwork')">
<table width="60%" border="0" align="center" cellpadding="1" cellspacing="5">
  <caption>
    <h2 align="left"><u><font color="#660000">ASSIGN MODULE TO EMPLOYEE</font></u></h2>
  </caption>
 
  </tr>
  <tr>
    <th align="left">Employee</th>
    <th align="left">:</th>
    <td align="left"><select name="empcode"><?php

	$sqlll="select * from employee where teamcode='$teamcode'";
$result2=mysql_query($sqlll)or die(mysql_error());

while($row2=mysql_fetch_array($result2))
{
?>

    <option value="<?php echo $row2['empcode'];?>"><?php echo $row2['empname'];?></option>
    <?php } ?>
    </select></td>
  </tr>
  <tr>
    <th align="left">Project Topic</th>
    <th align="left">:</th>
    <td align="left"><select name="emptopic" id="prtopic"  class="prtopic"onchange="prjt();" >
    <option>select</option> 
<?php
while($row=mysql_fetch_array($result))
{
	$work=$row['projecttopic'];
	$sql1="select * from adminwork where workid='$work'";
	$result1=mysql_query($sql1)or die(mysql_error());
	$row1=mysql_fetch_array($result1);
?>

    <option value="<?php echo $row['workid'];?>"><?php echo $row1['projecttopic'];?></option>
    <?php } ?>
    </select></td>
  </tr>
  </table>
  <div class="ans">
  </div>

<?php
if($_POST['submit'])
{
	$empcode=$_POST['empcode'];
    $prtopic=$_POST['prtopic'];
	$emptopic=$_POST['emptopic'];
	$modulename=$_POST['modulename'];
	
	$rname=$_FILES['module']['name'];
	$rtype=$_FILES['module']['type'];
	$rtmpname=$_FILES['module']['tmp_name'];
	$rrid=rand();
	$rname=$rrid.$rname;
	$rpath="employee/uploads/".$rname;
	if(($rtype=='application/pdf')||($rtype=='application/vnd.openxmlformats-officedocument.wordprocessingml.document')||($rtype=='application/msword'))
		{
		move_uploaded_file($rtmpname,$rpath);
		}
	$extra=$_POST['moduleextra'];
	$empwdate=$_POST['empwdate'];
	

	
	
	$sql="insert into employeework  values('','$empcode','$prtopic','$rpath','$modulename','$extra','$empwdate','','','On progress','1')";
mysql_query($sql)or die(mysql_error());
$sql1="update teamwork set status='1',workstatus='On progress' where workid='$emptopic'";
mysql_query($sql1)or die(mysql_error());
echo "<script>window.location='leader.php?view=assign_module'</script>";
}
?>
