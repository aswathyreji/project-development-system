<?php
require_once('../phpfiles/connection.php');
$prjt=$_REQUEST['prj'];
$sql="select * from teamwork where workid='$prjt'";
$result=mysql_query($sql)or die(mysql_error());
$row=mysql_fetch_array($result);
 $pr=$row['projecttopic'];
    $sql0="select * from adminwork where workid='$pr'";
	$result0=mysql_query($sql0)or die(mysql_error());
	$row0=mysql_fetch_array($result0);
    $prj=$row0['projecttopic'];

?>
<table width="60%" border="0" align="center" cellpadding="1" cellspacing="5">
 <tr><input name="prtopic" type="hidden" value="<?php echo $pr;?>" />
    <th align="left">Project</th>
    <th align="left">:</th>
    <td align="left" class="ans"><a href="<?php echo $row['project']; ?>" target="_blank"><?php echo $prj;?></a>
        
    </td>
  </tr>
  <tr>
    <th align="left">Module name</th>
    <th align="left">:</th>
    <td align="left"><input name="modulename" type="text" size="25" /></td>
  </tr>
  <tr>
    <th align="left">Attach</th>
    <th align="left">:</th>
    <td align="left"><input name="module" type="file" /></td>
  </tr>
  <tr>
    <th align="left">Extra</th>
    <th align="left">:</th>
    <td align="left"><textarea name="moduleextra" cols="19" rows="5"></textarea></td>
  </tr>
   <tr>
    <th align="left">Date by Manager</th>  
    <th align="left">:</th>
    <td align="left"> <?php echo $row['completiondate']; ?> <input name="teamdate" type="hidden" value="<?php echo $row['completiondate'];?>" /></td>
  </tr>
    <tr>
    <th align="left">completion date</th>  
    <th align="left">:</th>
    <td align="left">
    
        <input name="empwdate" type="text" id="empwdate"  class="textbox_slim" size="10" maxlength="13"  value="<?php echo $date;?>"  readonly="true" />
    <input type="button" name="Button" value="..." class="pagefooter" onclick="displayCalendar(document.getElementById('empwdate'),'yyyy-mm-dd',this); "  title="click here to view calender" />

    <!--<input name="empwdate" type="text" value="YYYY/MM/DD" size="25" maxlength="10" />--></td>
  </tr>
   <tr>
    <th align="left">&nbsp;</th>
    <th align="left">&nbsp;</th>
    <th align="left"><input name="submit" type="submit" value="SUBMIT" /><input name="reset" type="reset" value="RESET" /></th>
  </tr>
</table>
  
