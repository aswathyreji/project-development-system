<?php
class demo
{
	function demo()
	{
		switch($_REQUEST['view'])
		{
			case assign_module:
				include_once("leader/assign_module.php");	
				break;
			case leaderempworkstatus:
				include_once("leader/leaderempworkstatus.php");	
				break;
			case leaderworkstatus:
				include_once("leader/leaderworkstatus.php");	
				break;
			case sendmessage:
				include_once("leader/sendmessage.php");	
				break;
			case inbox:
				include_once("leader/inbox.php");
				break;
			case sentbox:
				include_once("leader/sentbox.php");
				break;
			case changepassword:
				include_once("leader/changepassword.php");	
				break;
			
			case about:
				include_once("leader/about.php");	
				break;
			case completed_wrk:
				include_once("leader/completed_wrk.php");	
				break;
		}
	}
	
}