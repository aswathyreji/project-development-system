<?php
require_once('phpfiles/connection.php');
$user=$_SESSION['leader']['username'];
$sql0="select mgrcode,teamcode from teamleader where username='$user'";
$result0=mysql_query($sql0)or die(mysql_error());
$row0=mysql_fetch_array($result0);
$mgrcode=$row0['mgrcode'];
$teamcode=$row0['teamcode'];

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<script type="text/javascript" src="phpfiles/jquery-1.4.js"></script>
<script type="text/javascript">
msgcheck1=function()
{

	var vals=$("#msg1").val();
	$.post("phpfiles/msg.php",{msgto:vals},function(data)
	{
		$(".ans").html(data);
		
	});
}
msgcheck2=function()
{

	var vals=$("#msg2").val();
	var vals1=$("#msg4").val();
	$.post("phpfiles/msg.php",{msgto:vals,mgr:vals1},function(data)
	{
		$(".ans").html(data);
		
	});
}
msgcheck3=function()
{

	var vals=$("#msg3").val();
	var vals1=$("#msg5").val();
	$.post("phpfiles/msg.php",{msgto:vals,tmlr:vals1},function(data)
	{
		$(".ans").html(data);
		
	});
}
</script>
</head>

<body>
<form action="#" method="post" name="msg" enctype="multipart/form-data">
<table width="200" border="0" align="center">
  <tr>
    <td colspan="3" bgcolor="#330000"><font color="#FFFFFF"><img src="images/compose.png" width="100" height="100"/>
      <h2 align="center">NEW MESSAGE</h2>
    </font></td>
  </tr>
  <tr>
    <td colspan="3" >
     <br />
   <b>Receiver&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</b>
    <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      
                 
        <label>
          <input type="radio" name="msgsend" value="admin" id="msg1" onclick="msgcheck1();"/>
          Administrator</label>
     
        <label>
          <input type="radio" name="msgsend" value="teamleadermgr" id="msg2" onclick="msgcheck2();"/>
          Manager</label>
          
           <label>
          <input type="radio" name="msgsend" value="teamleaderemply" id="msg3" onclick="msgcheck3();"/>
          Employee</label>
          
          <input name="mgcode" type="hidden" value="<?php echo $mgrcode;?>" id="msg4" />
        <input name="teamcode" type="hidden" value="<?php echo $teamcode;?>" id="msg5" />
      
      
       
       
      </p></td>
  </tr>
  <tr>
    <td><b>To</b></td>
    <td><b>:</b></td>
    <td><select name="to" class="ans">
    <option>select</option>
    </select>

  </tr>
  <tr>
    <td><b>Subject</b></td>
    <td><b>:</b></td>
    <td><input name="subject" type="text" size="25" /></td>
  </tr>
  <tr>
    <td><b>Attachment</b></td>
    <td><b>:</b></td>
    <td><input name="attach" type="file" /></td>
  </tr>
  <tr>
    <td><b>Message</b></td>
    <td><b>:</b></td>
    <td><textarea name="message" cols="50" rows="15"></textarea>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td><input name="send" type="submit" value="SEND" /></td>
  </tr>
</table>
<?php
if($_POST['send'])
{
	if($_POST['msgsend']=='admin')
	{
		$sendto="admin";
	}
	else if($_POST['msgsend']=='teamleadermgr')
	{
		$sendto=$_POST['to']." - manager";
	}
	else if($_POST['msgsend']=='teamleaderemply')
	{
		$sendto=$_POST['to']." - employee";
	}
	$sendfrom=$user." - teamleader";
    $subject=$_POST['subject'];
	$aname=$_FILES['attach']['name'];
	$atype=$_FILES['attach']['type'];
	$atmpname=$_FILES['attach']['tmp_name'];
	$arid=rand();
	$aname=$arid.$aname;
	$apath="leader/uploads/".$aname;
	if(($atype=='application/pdf')||($atype=='application/vnd.openxmlformats-officedocument.wordprocessingml.document')||($atype=='application/msword'))
		{
		move_uploaded_file($atmpname,$apath);
		}
	
	$message=$_POST['message'];
	$sql="insert into inbox values('','$sendto','$sendfrom','$subject','$message','$apath')";
mysql_query($sql);
$sql2="insert into sentitems values('','$sendfrom','$sendto','$subject','$message','$apath')";
mysql_query($sql2);
	echo "<script>alert('Message delivered successfully')</script>";
	echo "<script>window.location='leader.php?view=sendmessage'</script>";

}
?>
</form>

</body>
</html>