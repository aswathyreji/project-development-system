<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<table width="95%" border="0">
  <tr>
    <td width="10%">&nbsp;</td>
    <td width="85%"><h1>ABOUT US</h1>
      <br /><img src="images/Project-management-software.jpg"  height="200" align="left"  /><br />
                    <p>It is<b> project scrutinizer</b>. It is a free project management system. This site is developed by Manchu Mohan Msc Computer science student as a part of their completion of course. The site is developed using PHP as front end and My Sql as back end. <br />                    
                    <p>Project scrutinizer is a system that provides a web application for a software company for supporting the planning of human resources and project management. Resource planning is a key to success of any project. The main concepts of the system are tasks on one hand and employees on the other hand. Tasks need to be completed in a certain time by a limited amount of employees with specific skills. The system supports the process of associating tasks to the right employees in a way that due dates are met while every employee gets a constant workload and also the work of each of the employee can be analyzed efficiently. Project Scrutinizer offers better control and efficiency, ensuring the successful completion of your projects on time and within budget, but most importantly, respecting your company's work processes, thus eliminating the learning curve and associated costs of a work team using new software.  </p>
</tr>
</table>
</body>
</html>