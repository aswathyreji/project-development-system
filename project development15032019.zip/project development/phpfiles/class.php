<?php
class demo
{
	function demo()
	{
		switch($_REQUEST['view'])
		{
			case clientreg:
				include_once("phpfiles/clientreg.php");	
				break;
			
			case about:
				include_once("phpfiles/about.php");	
				break;
				
			case service:
				include_once("phpfiles/service.php");	
				break;
				
			case contact:
				include_once("phpfiles/contact.php");	
				break;
		}
	}
	
}