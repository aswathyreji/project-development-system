<?php
mysql_connect("localhost","root","");
mysql_select_db("scrutinizer");
error_reporting('NOTICE');
if($_REQUEST['submit'])
{
	
	$user=$_POST['c_uname'];
	$pass=md5($_POST['c_pass']);

$sql="select * from login where username='$user' and password='$pass' and status='1'";
$result=mysql_query($sql)or die(mysql_error());

	if(mysql_num_rows($result)>0)
	{
	
		$row=mysql_fetch_array($result);
		$username=$row['username'];
		$loginid=$row['loginid'];
		if($row['user']=="admin")
		{
			mysql_query("update login set online='1' where loginid='$loginid'");
			$_SESSION['admin']['username']=$username;
			echo "<script>window.location='admin.php'</script>";
		}
		else if($row['user']=='manager')
		{
			mysql_query("update login set online='1' where loginid='$loginid'");
			$_SESSION['manager']['username']=$username;
			echo "<script>window.location='manager.php'</script>";
			
		}
		else if($row['user']=='teamleader')
		{
			mysql_query("update login set online='1' where loginid='$loginid'");
			$_SESSION['leader']['username']=$username;
			echo "<script>window.location='leader.php'</script>";
			
		}
		else if($row['user']=='employee')
		{
			mysql_query("update login set online='1' where loginid='$loginid'");
			$_SESSION['emp']['username']=$username;
			echo "<script>window.location='employee.php'</script>";
			
		}
		else if($row['user']=='client')
		{
			mysql_query("update login set online='1' where loginid='$loginid'");
			$_SESSION['client']['username']=$username;
			echo "<script>window.location='client.php'</script>";
			
		}
	}

}
?>
        