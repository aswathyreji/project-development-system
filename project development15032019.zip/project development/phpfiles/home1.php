<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<!-- <table width="925" border="0">
          <tr>
            <td><div class="col_allw280">
              <p>The objective of the system is providing a web application for a software company for supporting the planning of human resources and project management. Resource planning is a key to success of any project. The main concepts of the system are tasks on one hand and employees on the other hand. Tasks need to be completed in a certain time by a limited amount of employees with specific skills. The system supports the process of associating tasks to the right employees in a way that due dates are met while every employee gets a constant workload and also the work of each of the employee can be analyzed efficiently.  </p>
            </div>
              <div class="col_allw280">
                <h3>Services</h3>
                <p>The software being developed has the following features:</p>
               
                <ul class="tmo_list">
                  <li> the system is being developed with the user friendly uis. </li>
                  <li>various authentication and access levels are handled.</li>
                  <li>information files about the employees, clients, and other users can be stored in a centralized database. </li>
                </ul>
                <div class="cleaner"></div>
              </div><div class="col_allw280 col_last">
                <h3>News Updates</h3>
                <br /><table width="100%" height="290" border="0">
  <tr>
    <td align="left" valign="top"><marquee direction="up" scrolldelay="80" scrollamount="1" onmouseover="this.stop();" onmouseout="this.start();" height="280px"><p align="justify"><?php echo $rown['news']; ?></p></marquee></td>
  </tr>
</table>
              </div>
            <div class="cleaner"></div></td>
          </tr>
        </table>-->
                
                
                	<h1>WELCOME TO OUR BUSINESS COMPANY !</h1>
               	  <p><img alt="Image" src="images/templatemo_image.jpg" />              <p>The objective of the system is providing a web application for a software company for supporting the planning of human resources and project management. Resource planning is a key to success of any project. The main concepts of the system are tasks on one hand and employees on the other hand. Tasks need to be completed in a certain time by a limited amount of employees with specific skills. The system supports the process of associating tasks to the right employees in a way that due dates are met while every employee gets a constant workload and also the work of each of the employee can be analyzed efficiently.  </p>
</p>
           	  <div id="templatemo_bottom_section">
                    	<div class="templatemo_bottom_section_box">
                        	<h2>COMPANY BRIEF</h2>
                            <img alt="company" src="images/templatemo_image_1.jpg" />
                       	  <h3>Praesent mattis varius quam</h3>
							<p>Vestibulum ullamcorper ipsum nec augue. Vestibulum auctor odio eget ante.</p><br />
                            <p>Nunc commodo, magna pharetra semper vehicula, dui ligula feugiat elit, et euismod nunc orci ut libero.</p>
        </div>
                        
                        <div class="templatemo_bottom_section_box">
                        	<h2>FUTURE PROGRAMS</h2>
                            <img alt="company" src="images/templatemo_image_2.jpg" />
                     		<ul>
                            	<li><a href="#">Donec sem pede, fringilla</a></li>
                                <li><a href="#">Neque eget ante tristiqu</a></li>
                                <li><a href="#">Consectetur adipiscing elit</a></li>
                                <li><a href="#">Duis blandit pharetra dui</a></li>
                            </ul>
                            <ul>
                                <li><a href="#">Morbi nec magna pulvinar</a></li>
                                <li><a href="#">Consectetur adipiscing elit</a></li>
                                <li><a href="#">Suspendisse ac magna quis</a></li>
                                <li><a href="#">Mattis imper diet, suscipit</a></li>
                            </ul>

                        </div>
                        
                        <div class="templatemo_bottom_section_box">
                        	<h2>NEW SERVICES</h2>
                          <img alt="products" src="images/templatemo_image_3.jpg" /><br />
                          <ul>
                            <li> the system is being developed with the user friendly uis. </li>
                  <li>various authentication and access levels are handled.</li>
                  <li>information files about the employees, clients, and other users can be stored in a centralized database. </li>
                  </ul>
              </div>
                        
                  </div>
</body>
</html>