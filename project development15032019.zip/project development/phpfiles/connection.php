<?php
mysql_connect("localhost","root","");
mysql_select_db("scrutinizer");
error_reporting('E_NOTICE');
?>