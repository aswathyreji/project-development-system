<?php
error_reporting("E_NOTICE");
session_start();
require_once('phpfiles/connection.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<script src="validation/gen_validatorv31.js" type="text/javascript"></script>
	<script language="javascript">

function Validate() 
{

   
 }
}</script>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Client registration</title>
</head>

<body>
<?php
if($_POST['submit'])
{
$clname=$_POST['cname'];
$cloccu=$_POST['coccu'];
$claddrs=$_POST['caddrs'];
$clage=$_POST['cage'];
$clgen=$_POST['cgen'];
$clemail=$_POST['cemail'];
$clphone=$_POST['cphone'];
$cldescr=$_POST['cdescr'];
$cluname=$_POST['cuname'];
$clpass=md5($_POST['cpass']);
$clconpass=$_POST['cconpass'];
$sql3="select * from login where username='$cluname' ";
		$result3=mysql_query($sql3);
		if(mysql_num_rows($result3)>0)
		{
			echo "<script>alert('This username not available! Please choose a different one')</script>";
			echo "<script>window.location='index.php?view=frmclientreg'</script>";
		}
		else
		{

$sql="insert into client values('','$clname','$cloccu','$claddrs','$clage','$clgen','$cluname','$clemail','$clphone','$cldescr')";
mysql_query($sql);

$sql1="insert into login values('','client','$cluname','$clpass','1','0','$clemail')";
mysql_query($sql1);
			echo "<script>alert('Successfully registered')</script>";
		    echo "<script>window.location='index.php?view=frmclientreg'</script>";
}}

?>

<form name="frmclientreg" action="" method="post" enctype="multipart/form-data" onsubmit="return Validate()">
<table border="0" cellspacin="5" cellpadding="1" width="60%" align="center">
<caption><font color="#660000"><h2 align="left"><u>CLIENT REGISTRATION</u></h2></font></caption>
<tr>
<th align="left" width="31%">Name</th>
<th align="left" width="5%">:</th>
<td width="64%" align="left"><input name="cname" id="cname" type="text" size="25"/></td>
</tr>
<tr>
<th align="left">Occupation</th>
<th align="left">:</th>
<td align="left"><input name="coccu" id="coccu" type="text"  size="25"/></td>
</tr>
<tr>
<th align="left">Address</th>
<th align="left">:</th>
<td align="left"><textarea name="caddrs" id="caddrs" cols="25" rows="5"  ></textarea>
</td>
</tr>
<tr>
<th align="left">Age</th>
<th align="left">:</th>
<td align="left"><input name="cage"  id="cage" type="text"  size="10" maxlength="2"/>
</td>
</tr>
<tr>
<th align="left">Sex</th>
<th align="left">:</th>
<td align="left">Male<input type="radio" name="cgen" value="M" checked="checked"/>
Female<input type="radio"  value="F" name="cgen" id="cgen"/></td>
</tr>
<tr>
<th align="left">email</th>
<th align="left">:</th>
<td align="left"><input name="cemail" id="cemail" type="text" value="" size="25"/></td>
</tr>
<tr>
<th align="left">Phone No</th>
<th align="left">:</th>
<td align="left"><input name="cphone" id="cphone" type="text" size="25" /></td>
</tr>
<tr>
<th align="left">Work Description</th>
<th align="left">:</th>
<td align="left"><textarea name="cdescr" id="cdescr" cols="25" rows="5"></textarea>
</td>
</tr>
<tr>
<th align="left">Username</th>
<th align="left">:</th>
<td align="left"><input name="cuname" type="text" size="25"/></td>
</tr>
<tr>
<th align="left">Password</th>
<th align="left">:</th>
<td align="left"><input name="cpass" id="cpass" type="password"  size="25"/></td>
</tr>
<tr>
<th align="left">Confirm password</th>
<th align="left">:</th>
<td align="left"><input name="cconpass" id="cconpass" type="password" size="25"/></td>
</tr>
<tr>
<td align="left">&nbsp;</td>
<td align="left">&nbsp;</td>
<td align="left">&nbsp;</td>
</tr>
<tr>
<td align="left">&nbsp;</td>
<td align="left">&nbsp;</td>
<td align="left"><input name="submit" type="submit"  value="SUBMIT" />
<input name="reset" type="reset"  value="RESET"/></td>
</tr>
</table>

</form>
<script  language="javascript" type="text/javascript">
function Validate() 
{
if(document.frmclientreg.cname.value=="")
{
alert("Pls enter Your name ");
return false;
}
else
{
if (!document.frmclientreg.cname.value.match(/^[a-zA-Z]+$/)) 
   {
        alert('Only alphabets are allowed');
        return false;   
   }
}
if(document.frmclientreg.coccu.value=="")
{
alert("Pls enter Your occupation");
return false;
}
if (document.frmclientreg.caddrs.value == "")
{
alert(" Pls enter the permanent address");
return false;
}
if(document.frmclientreg.cage.value=="")
{
alert("Enter your age");
return false;
}
else
{
if(isNaN(document.frmclientreg.cage.value)==true||document.frmclientreg.cage.value>100)
{
alert("invalid age");
return false;
}
}
	
var email = document.getElementById('cemail');
var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
if(document.frmclientreg.cemail.value=="")
{
alert("Pls enter Your email ");
return false;
}
	else{
if (!filter.test(email.value)) {
    alert('Please provide a valid email address');
    return false;
}
	}
var phoneNumber = document.getElementById('cphone').value;
var phoneRGEX = /^[(]{0,1}[0-9]{3}[)]{0,1}[-\s\.]{0,1}[0-9]{3}[-\s\.]{0,1}[0-9]{4}$/;
var phoneResult = phoneRGEX.test(phoneNumber);
if(document.frmclientreg.cphone.value=="")
{
alert("Pls enter Your mobile no ");
return false;
}
if(phoneResult == false)
{
alert('Please enter a valid phone number');
return false;
}
if (document.frmclientreg.cdescr.value == "")
{
alert(" Pls enter the Work Description");
return false;
}

if (document.frmclientreg.cuname.value == "")
{
alert(" Pls enter the username");
return false;
}
var password=document.frmclientreg.cpass.value;  
  
if (password==null || password=="")
{  
  alert("Pls enter the password");  
  return false;  
}
else if(password.length<8)
{  
  alert("Password must be at least 8 characters long.");  
  return false;  
  } 
var password=document.frmclientreg.cconpass.value;  
  
if (password==null || password=="")
{  
  alert("Pls enter the conform password");  
  return false;  
}
else if(password.length<8)
{  
  alert("Password must be at least 8 characters long.");  
  return false;  
  } 
var password = document.getElementById("cpass").value;
var confirmPassword = document.getElementById("cconpass").value;
	
if (password != confirmPassword) {
alert("Passwords do not match.");
return false;
}
return true;
        }
</script>
</body>
</html>
