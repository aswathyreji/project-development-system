<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<table width="95%" border="0">
  <tr>
    <td width="10%">&nbsp;</td>
    <td width="85%"><h1>Services</h1>
      <br />
<h1>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Our featured services...</h1>
               
                <ul class="tmo_list">
                  <li><font color="#990033"><h2>PROJECT MANAGEMENT</h2></font></li>
                  <li><font color="#00FFCC"><h2>HUMAN RESOURCE MANAGEMENT</h2></font></li>
                  <li><font color="#669999"><h2>TIME MANAGEMENT</h2></font></li>
                </ul>
		<br /><br /><br /><br /><h1><font color="#FF0099"><b>YOUR SATISFACTION IS OUR AIM... Keep smiling  :)</b></font></h1>
</td>
  </tr>
</table>
<h2>&nbsp;</h2>
</body>
</html>