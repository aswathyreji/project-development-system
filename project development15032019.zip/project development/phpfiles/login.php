<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<form action="" method="post">              
<table border="0" cellspacing="5" cellpadding="1" width="20%" align="center" >
<tr>
<th align="left"><font color="#000000">Username:</font></th>
<td align="left"><input name="c_uname" type="text" size="16"/></td>
</tr>
<tr>
<th align="left"><font color="#000000">Password:</font></th>
<td align="left"><input name="c_pass" type="password"  size="16"/></td>
</tr>
<tr>
<th></th>
	<td align="left">&nbsp;&nbsp;&nbsp;&nbsp;<input name="submit" type="submit"  value="Login"/></td>

<!--	<td align="left"><a href="../web/index.html"><h4><font color="#FFFF00">Forgot Password</font></h4></a></td>-->
</tr>
</table>
</form>    

</body>
</html>