<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
    <h1><font color="#990099">DEVELOPERS</font></h1><br />
     
    
     <p> <font color="#FF0066"><strong>Manchu Mohan. <br />
ph:+919645952813,</strong><strong><br />
		 email:manchumohan1993@gmail.com</strong><strong><br /></strong></font></p>
<p><br /></p>
		
</body>
</html>