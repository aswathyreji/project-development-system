<?php
require_once('connection.php');
$user=$_SESSION['username'];

$msgto=$_REQUEST['msgto'];
if($msgto=="admin")
{
$sql="select * from login where user='admin'";
$result=mysql_query($sql)or die(mysql_error());
while($row=mysql_fetch_array($result))
{?>
	 <option ><?php echo $row['username'];?></option>
	<?php
}
}
if($msgto=="manager")
{
$sql="select * from login where user='manager'";
$result=mysql_query($sql)or die(mysql_error());
?>
 <option>select</option>
 <?php
while($row=mysql_fetch_array($result))
{?>
	 <option ><?php echo $row['username'];?></option>
	<?php
}
}
if($msgto=="teamleader")
{
$sql="select * from login where user='teamleader'";
$result=mysql_query($sql)or die(mysql_error());
?>
 <option>select</option>
 <?php
while($row=mysql_fetch_array($result))
{?>
	 <option ><?php echo $row['username'];?></option>
	<?php
}
}
if($msgto=="employee")
{
$sql="select * from login where user='employee'";
$result=mysql_query($sql)or die(mysql_error());
?>
 <option>select</option>
 <?php
while($row=mysql_fetch_array($result))
{?>
	 <option ><?php echo $row['username'];?></option>
	<?php
}
}
if($msgto=="client")
{
$sql="select * from login where user='client'";
$result=mysql_query($sql)or die(mysql_error());
?>
 <option>select</option>
 <?php
while($row=mysql_fetch_array($result))
{?>
	 <option ><?php echo $row['username'];?></option>
	<?php
}
}
if($msgto=="mgrteamleader")
{
	$mgr=$_REQUEST['mgr'];
$sql="select * from teamleader where mgrcode='$mgr'";
$result=mysql_query($sql)or die(mysql_error());
?>
 <option>select</option>
 <?php
while($row=mysql_fetch_array($result))
{?>
	 <option ><?php echo $row['username'];?></option>
	<?php
}
}
if($msgto=="teamleadermgr")
{
	$mgr=$_REQUEST['mgr'];
$sql="select * from manager where mgrcode='$mgr'";
$result=mysql_query($sql)or die(mysql_error());

while($row=mysql_fetch_array($result))
{?>
	 <option ><?php echo $row['username'];?></option>
	<?php
}
}
if($msgto=="teamleaderemply")
{
	$tmlr=$_REQUEST['tmlr'];
$sql="select * from employee where teamcode='$tmlr'";
$result=mysql_query($sql)or die(mysql_error());
?>
 <option>select</option>
 <?php
while($row=mysql_fetch_array($result))
{?>
	 <option ><?php echo $row['username'];?></option>
	<?php
}
}
if($msgto=="empteamleader")
{
	$tmlr=$_REQUEST['tmlr'];
$sql="select * from teamleader where teamcode='$tmlr'";
$result=mysql_query($sql)or die(mysql_error());

while($row=mysql_fetch_array($result))
{?>
	 <option ><?php echo $row['username'];?></option>
	<?php
}
}
?>